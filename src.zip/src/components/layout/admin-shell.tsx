"use client";

import {
  BadgeDollarSign,
  Boxes,
  ClipboardCheck,
  FileClock,
  Home,
  LogOut,
  Megaphone,
  PackageSearch,
  ReceiptText,
  Settings,
  ShieldCheck,
  ShoppingBag,
  Star,
  Truck,
  Users,
  Warehouse,
} from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { toast } from "sonner";

import { useCurrentAdmin } from "@/features/auth/use-current-admin";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/dashboard", label: "لوحة التحكم", icon: Home },
  { href: "/users", label: "المستخدمون", icon: Users },
  { href: "/vendors", label: "البائعون", icon: Warehouse },
  { href: "/verifications", label: "التحقق والوثائق", icon: ShieldCheck },
  { href: "/products", label: "المنتجات", icon: PackageSearch },
  { href: "/catalog", label: "الكتالوج", icon: Boxes },
  { href: "/orders", label: "الطلبات", icon: ShoppingBag },
  { href: "/bulk-orders", label: "طلبات الجملة", icon: ClipboardCheck },
  { href: "/reviews", label: "المراجعات", icon: Star },
  { href: "/payments", label: "المدفوعات والاسترداد", icon: BadgeDollarSign },
  { href: "/refunds", label: "الاستردادات", icon: ReceiptText },
  { href: "/billing", label: "فواتير البائعين", icon: ReceiptText },
  { href: "/shipping", label: "الشحن", icon: Truck },
  { href: "/promotions", label: "العروض", icon: Megaphone },
  { href: "/banners", label: "البانرات", icon: FileClock },
  { href: "/settings", label: "الإعدادات", icon: Settings },
  { href: "/audit-logs", label: "سجل التدقيق", icon: FileClock },
  { href: "/ops", label: "تشغيل النظام", icon: ShieldCheck },
];

export function AdminShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { data: admin } = useCurrentAdmin();
  const displayName = admin?.fullName ?? admin?.name ?? admin?.email ?? "مسؤول";

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    toast.success("تم تسجيل الخروج");
    router.replace("/login");
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-950">
      <aside className="fixed inset-y-0 right-0 hidden w-72 border-l border-slate-200 bg-white lg:block">
        <div className="flex h-16 items-center border-b border-slate-200 px-5">
          <div>
            <div className="text-base font-semibold">إدارة يلا نيو</div>
            <div className="text-xs text-slate-500">عمليات السوق</div>
          </div>
        </div>
        <nav className="h-[calc(100vh-4rem)] overflow-y-auto px-3 py-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive =
              pathname === item.href || pathname.startsWith(`${item.href}/`);

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "mb-1 flex h-10 items-center gap-3 rounded-md px-3 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-950",
                  isActive && "bg-teal-50 text-teal-800",
                )}
              >
                <Icon className="h-4 w-4" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </aside>
      <div className="lg:pr-72">
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-slate-200 bg-white px-4 lg:px-8">
          <div>
            <div className="text-sm font-semibold text-slate-900">
              مركز العمليات
            </div>
            <div className="text-xs text-slate-500">
              مسجل الدخول باسم {displayName}
            </div>
          </div>
          <button
            type="button"
            onClick={handleLogout}
            className="inline-flex h-9 items-center gap-2 rounded-md border border-slate-200 px-3 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-100"
          >
            <LogOut className="h-4 w-4" />
            تسجيل الخروج
          </button>
        </header>
        <main className="px-4 py-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
}
