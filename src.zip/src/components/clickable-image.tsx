"use client";

import { useState, useEffect, useCallback } from "react";
import { X, ZoomIn, ZoomOut, Maximize } from "lucide-react";

interface ClickableImageProps {
  src: string;
  alt?: string;
  className?: string;
  thumbnailClassName?: string;
  onError?: () => void;
}

export function ClickableImage({ src, alt = "Image", className = "", thumbnailClassName = "", onError }: ClickableImageProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scale, setScale] = useState(1);

  const handleClose = useCallback(() => {
    setIsOpen(false);
    setScale(1);
  }, []);

  const handleKeyDown = useCallback(
    (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        handleClose();
      }
    },
    [handleClose]
  );

  useEffect(() => {
    if (isOpen) {
      document.addEventListener("keydown", handleKeyDown);
      // Prevent scrolling of body when lightbox is open
      document.body.style.overflow = "hidden";
    } else {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    }
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  }, [isOpen, handleKeyDown]);

  const zoomIn = () => setScale((s) => Math.min(4, s + 0.25));
  const zoomOut = () => setScale((s) => Math.max(0.5, s - 0.25));
  const resetZoom = () => setScale(1);

  return (
    <>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={src}
        alt={alt}
        className={`cursor-zoom-in transition-all duration-200 hover:opacity-90 ${thumbnailClassName} ${className}`}
        onClick={() => setIsOpen(true)}
        onError={onError}
      />

      {isOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 transition-opacity duration-300 animate-in fade-in"
          onClick={handleClose}
        >
          {/* Lightbox Content Container */}
          <div 
            className="relative flex flex-col items-center justify-center max-h-screen max-w-4xl w-full"
            onClick={(e) => e.stopPropagation()} // Stop click propagation to backdrop
          >
            {/* Control Panel */}
            <div className="absolute top-[-50px] left-0 right-0 flex justify-between items-center px-2 text-white">
              <span className="text-sm font-medium truncate max-w-xs md:max-w-md" dir="rtl">
                {alt}
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={zoomOut}
                  className="rounded-full bg-slate-800/80 p-2 hover:bg-slate-700 transition-colors"
                  title="تصغير"
                >
                  <ZoomOut className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={zoomIn}
                  className="rounded-full bg-slate-800/80 p-2 hover:bg-slate-700 transition-colors"
                  title="تكبير"
                >
                  <ZoomIn className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={resetZoom}
                  className="rounded-full bg-slate-800/80 p-2 hover:bg-slate-700 transition-colors"
                  title="إعادة ضبط الحجم"
                >
                  <Maximize className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={handleClose}
                  className="rounded-full bg-red-600/95 p-2 hover:bg-red-700 transition-colors mr-2"
                  title="إغلاق (Esc)"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Image Box */}
            <div className="overflow-auto max-h-[80vh] max-w-full rounded-md shadow-2xl bg-slate-900 border border-slate-800 flex items-center justify-center">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={src}
                alt={alt}
                style={{ transform: `scale(${scale})` }}
                className="max-h-[75vh] max-w-full object-contain transition-transform duration-200 ease-out"
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
}
