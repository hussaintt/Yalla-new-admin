export function LoadingState({ label = "جار التحميل" }: { label?: string }) {
  return (
    <div className="rounded-md border border-slate-200 bg-white p-6 text-sm text-slate-500">
      {label}...
    </div>
  );
}

export function EmptyState({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <div className="rounded-md border border-dashed border-slate-300 bg-white p-8">
      <div className="text-sm font-semibold text-slate-900">{title}</div>
      <p className="mt-2 max-w-xl text-sm leading-6 text-slate-500">
        {description}
      </p>
    </div>
  );
}

export function ErrorState({ message }: { message: string }) {
  return (
    <div className="rounded-md border border-red-200 bg-red-50 p-4 text-sm text-red-700">
      {message}
    </div>
  );
}
