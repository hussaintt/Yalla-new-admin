import { useState, useRef, useEffect } from "react";
import { toast } from "sonner";
import { UploadCloud, X, Loader2 } from "lucide-react";

interface ImageUploadInputProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  purpose: string;
  required?: boolean;
}

export function ImageUploadInput({
  label,
  value,
  onChange,
  purpose,
  required,
}: ImageUploadInputProps) {
  const [uploading, setUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (value) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setPreviewUrl(`/api/admin/files/${value}`);
    } else {
      setPreviewUrl(null);
    }
  }, [value]);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate size (5MB limit for banners)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("الملف كبير جداً. الحد الأقصى 5 ميجابايت");
      return;
    }

    setUploading(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch(`/api/admin/files/upload?purpose=${purpose}`, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData?.message || "فشل تحميل الملف");
      }

      const result = (await response.json()) as { publicId?: string };
      if (result.publicId) {
        onChange(result.publicId);
        toast.success("تم تحميل الصورة بنجاح");
      } else {
        throw new Error("لم يتم إرجاع معرف الملف");
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "حدث خطأ أثناء تحميل الصورة");
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleRemove = () => {
    onChange("");
    setPreviewUrl(null);
  };

  return (
    <div className="space-y-2">
      <label className="block text-sm font-semibold text-slate-700">
        {label}
        {required && <span className="text-red-500 mr-1">*</span>}
      </label>
      
      <div className="flex items-center gap-4">
        {previewUrl ? (
          <div className="relative h-24 w-44 overflow-hidden rounded-md border border-slate-200 bg-slate-50 shadow-sm group">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={previewUrl}
              alt="Preview"
              className="h-full w-full object-cover"
              onError={() => {
                // If it fails to load (e.g. not an image or unauthorized), clear preview
                setPreviewUrl(null);
              }}
            />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <button
                type="button"
                onClick={handleRemove}
                className="rounded-full bg-red-600 p-2 text-white hover:bg-red-700 shadow-md transition-colors"
                title="إزالة الصورة"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="flex h-24 w-44 flex-col items-center justify-center rounded-md border-2 border-dashed border-slate-300 hover:border-teal-600 hover:bg-slate-50/50 transition-all disabled:opacity-50 cursor-pointer"
          >
            {uploading ? (
              <div className="flex flex-col items-center gap-2">
                <Loader2 className="h-6 w-6 animate-spin text-teal-600" />
                <span className="text-xs text-slate-500 font-medium">جاري الرفع...</span>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 text-slate-400">
                <UploadCloud className="h-6 w-6 text-slate-400" />
                <span className="text-xs font-semibold text-slate-500">اختر صورة</span>
              </div>
            )}
          </button>
        )}
        
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/jpeg,image/png,image/webp"
          className="hidden"
        />
        
        <div className="text-xs text-slate-500 space-y-1">
          <div>الصيغ المقبولة: JPG, PNG, WEBP</div>
          <div>الحد الأقصى للملف: 5 ميجابايت</div>
          {value && (
            <div className="flex items-center gap-1 font-mono text-[10px] text-slate-400 mt-1 select-all bg-slate-100 px-1.5 py-0.5 rounded">
              <span>ID:</span>
              <span className="truncate max-w-[120px]" title={value}>{value}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
