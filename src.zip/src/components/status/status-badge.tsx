import { cn } from "@/lib/utils";

const statusGroups = {
  green: ["ACTIVE", "APPROVED", "PAID", "DELIVERED", "COMPLETED", "SUCCESS"],
  yellow: ["PENDING", "PROCESSING", "AWAITING_REVIEW", "REVIEW"],
  red: ["REJECTED", "FAILED", "SUSPENDED", "CANCELLED", "CANCELED"],
  gray: ["ARCHIVED", "EXPIRED", "INACTIVE", "DELETED", "DRAFT"],
};

function statusClassName(status: string) {
  const normalized = status.toUpperCase();

  if (statusGroups.green.includes(normalized)) {
    return "bg-emerald-50 text-emerald-700 ring-emerald-200";
  }
  if (statusGroups.yellow.includes(normalized)) {
    return "bg-amber-50 text-amber-700 ring-amber-200";
  }
  if (statusGroups.red.includes(normalized)) {
    return "bg-red-50 text-red-700 ring-red-200";
  }
  if (statusGroups.gray.includes(normalized)) {
    return "bg-slate-100 text-slate-700 ring-slate-200";
  }

  return "bg-sky-50 text-sky-700 ring-sky-200";
}

export function StatusBadge({ status }: { status: string }) {
  return (
    <span
      className={cn(
        "inline-flex h-6 items-center rounded-md px-2 text-xs font-medium ring-1 ring-inset",
        statusClassName(status),
      )}
    >
      {status.replaceAll("_", " ")}
    </span>
  );
}
