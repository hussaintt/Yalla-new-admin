"use client";

import { Search, X } from "lucide-react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { FormEvent, useState } from "react";

export function TableToolbar({
  searchPlaceholder = "بحث",
  statusOptions = [],
  showSearch = true,
}: {
  searchPlaceholder?: string;
  statusOptions?: Array<{ label: string; value: string }>;
  showSearch?: boolean;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [q, setQ] = useState(searchParams.get("q") ?? "");
  const status = searchParams.get("status") ?? "";

  function updateParams(next: Record<string, string>) {
    const params = new URLSearchParams(searchParams.toString());

    Object.entries(next).forEach(([key, value]) => {
      if (value) params.set(key, value);
      else params.delete(key);
    });
    params.delete("cursor");

    const query = params.toString();
    router.push(query ? `${pathname}?${query}` : pathname);
  }

  function handleSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    updateParams({ q });
  }

  return (
    <div className="flex flex-col gap-3 rounded-md border border-slate-200 bg-white p-3 md:flex-row md:items-center md:justify-between">
      {showSearch ? (
        <form onSubmit={handleSearch} className="flex gap-2">
          <label className="flex h-10 min-w-0 flex-1 items-center gap-2 rounded-md border border-slate-200 px-3 md:w-80">
            <Search className="h-4 w-4 text-slate-400" />
            <input
              value={q}
              onChange={(event) => setQ(event.target.value)}
              placeholder={searchPlaceholder}
              className="w-full border-0 bg-transparent text-sm outline-none"
            />
          </label>
          <button
            type="submit"
            className="h-10 rounded-md bg-teal-700 px-4 text-sm font-semibold text-white transition-colors hover:bg-teal-800"
          >
            بحث
          </button>
        </form>
      ) : (
        <div />
      )}

      <div className="flex items-center gap-2">
        {statusOptions.length > 0 ? (
          <select
            value={status}
            onChange={(event) => updateParams({ status: event.target.value })}
            className="h-10 rounded-md border border-slate-200 bg-white px-3 text-sm outline-none"
          >
            <option value="">كل الحالات</option>
            {statusOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        ) : null}
        <button
          type="button"
          onClick={() => {
            setQ("");
            router.push(pathname);
          }}
          className="inline-flex h-10 items-center gap-2 rounded-md border border-slate-200 px-3 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-100"
        >
          <X className="h-4 w-4" />
          إعادة ضبط
        </button>
      </div>
    </div>
  );
}
