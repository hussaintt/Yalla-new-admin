"use client";

export function CursorDataTable<TData>({
  columns,
  data,
  emptyLabel = "لا توجد بيانات.",
  getRowKey,
}: {
  columns: Array<{
    id: string;
    header: React.ReactNode;
    cell: (row: TData) => React.ReactNode;
  }>;
  data: TData[];
  emptyLabel?: string;
  getRowKey?: (row: TData, index: number) => string | number;
}) {
  return (
    <div className="overflow-hidden rounded-md border border-slate-200 bg-white">
      <table className="w-full border-collapse text-left text-sm">
        <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
          <tr>
            {columns.map((column) => (
              <th key={column.id} className="px-4 py-3 font-semibold">
                {column.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr>
              <td
                className="px-4 py-8 text-center text-slate-500"
                colSpan={columns.length}
              >
                {emptyLabel}
              </td>
            </tr>
          ) : (
            data.map((row, rowIndex) => (
              <tr
                key={getRowKey?.(row, rowIndex) ?? rowIndex}
                className="border-t border-slate-100"
              >
                {columns.map((column) => (
                  <td key={column.id} className="px-4 py-3 align-middle">
                    {column.cell(row)}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
