"use client";

export function ConfirmActionDialog({
  title,
  description,
  actionLabel,
  onConfirm,
  disabled,
}: {
  title: string;
  description: string;
  actionLabel: string;
  onConfirm: () => void;
  disabled?: boolean;
}) {
  return (
    <div className="rounded-md border border-slate-200 bg-white p-4">
      <div className="text-sm font-semibold text-slate-900">{title}</div>
      <p className="mt-1 text-sm leading-6 text-slate-500">{description}</p>
      <button
        type="button"
        disabled={disabled}
        onClick={onConfirm}
        className="mt-4 inline-flex h-9 items-center rounded-md bg-red-600 px-3 text-sm font-medium text-white transition-colors hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
      >
        {actionLabel}
      </button>
    </div>
  );
}
