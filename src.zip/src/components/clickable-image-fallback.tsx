"use client";

import { useState } from "react";
import { ClickableImage } from "./clickable-image";
import { FileText, ExternalLink } from "lucide-react";

interface ClickableImageWithFileFallbackProps {
  src: string;
  alt?: string;
  className?: string;
  fallbackLabel?: string;
}

export function ClickableImageWithFileFallback({
  src,
  alt = "مستند",
  className = "",
  fallbackLabel = "عرض المستند"
}: ClickableImageWithFileFallbackProps) {
  const [hasError, setHasError] = useState(false);
  const isPdf = src.toLowerCase().endsWith(".pdf") || src.includes("/pdf") || src.includes("format=pdf");

  if (isPdf || hasError) {
    return (
      <a
        href={src}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-100 hover:border-slate-300 transition-all cursor-pointer shadow-xs"
        title="فتح المستند في علامة تبويب جديدة"
      >
        <FileText className="h-4 w-4 text-slate-500" />
        <span className="font-semibold">{fallbackLabel}</span>
        <ExternalLink className="h-3 w-3 text-slate-400" />
      </a>
    );
  }

  return (
    <ClickableImage
      src={src}
      alt={alt}
      className={className}
      onError={() => setHasError(true)}
    />
  );
}
