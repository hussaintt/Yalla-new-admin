import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

import { accessCookieName } from "@/lib/auth/cookies";

const publicPaths = ["/login"];

export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const hasAccessToken = Boolean(request.cookies.get(accessCookieName)?.value);

  if (publicPaths.includes(pathname) && hasAccessToken) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  if (!publicPaths.includes(pathname) && !hasAccessToken) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("next", pathname);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico|.*\\..*).*)"],
};
