import { OpsHealthPage } from "@/features/resources/remaining-admin-pages";

export default function OpsHealthRoute() {
  return <OpsHealthPage />;
}
