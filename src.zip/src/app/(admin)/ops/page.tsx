import { OpsPage } from "@/features/resources/admin-resource-pages";

export default function OpsRoute() {
  return <OpsPage />;
}
