import { OpsQueuesPage } from "@/features/resources/remaining-admin-pages";

export default function OpsQueuesRoute() {
  return <OpsQueuesPage />;
}
