import { OpsGapPage } from "@/features/resources/remaining-admin-pages";

export default function OpsWebhooksRoute() {
  return <OpsGapPage title="أحداث Webhook" description="متابعة وإعادة محاولة أحداث Webhook عند إضافة endpoints التشغيل." />;
}
