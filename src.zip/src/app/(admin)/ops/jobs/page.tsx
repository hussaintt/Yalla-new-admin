import { OpsGapPage } from "@/features/resources/remaining-admin-pages";

export default function OpsJobsRoute() {
  return <OpsGapPage title="مهام النظام" description="تشغيل ومتابعة المهام اليدوية عند إضافة endpoints jobs." />;
}
