import { ProductsPage } from "@/features/resources/admin-resource-pages";

export default function ProductsRoute() {
  return <ProductsPage />;
}
