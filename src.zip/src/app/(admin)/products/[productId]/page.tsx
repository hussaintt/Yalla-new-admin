import { ProductDetailPage as ProductDetail } from "@/features/resources/admin-resource-pages";

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ productId: string }>;
}) {
  const { productId } = await params;

  return <ProductDetail productId={productId} />;
}
