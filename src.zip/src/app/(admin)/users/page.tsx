import { Suspense } from "react";

import { LoadingState } from "@/components/state/async-states";
import UsersPage from "@/features/users/users-page";

export default function UsersRoute() {
  return (
    <Suspense fallback={<LoadingState label="جار تحميل المستخدمين" />}>
      <UsersPage />
    </Suspense>
  );
}
