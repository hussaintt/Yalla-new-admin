import { UserDetailPage } from "@/features/resources/remaining-admin-pages";

export default async function UserDetailRoute({
  params,
}: {
  params: Promise<{ userId: string }>;
}) {
  const { userId } = await params;

  return <UserDetailPage userId={userId} />;
}
