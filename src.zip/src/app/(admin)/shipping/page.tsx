import { ShippingPage } from "@/features/resources/admin-resource-pages";

export default function ShippingRoute() {
  return <ShippingPage />;
}
