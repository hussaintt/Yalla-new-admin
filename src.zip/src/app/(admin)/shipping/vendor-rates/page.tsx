import { ShippingVendorRatesPage } from "@/features/resources/remaining-admin-pages";

export default function ShippingVendorRatesRoute() {
  return <ShippingVendorRatesPage />;
}
