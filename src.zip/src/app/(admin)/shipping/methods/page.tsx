import { ShippingMethodsPage } from "@/features/resources/remaining-admin-pages";

export default function ShippingMethodsRoute() {
  return <ShippingMethodsPage />;
}
