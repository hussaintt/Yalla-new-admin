import { ShippingQuoteTesterPage } from "@/features/resources/remaining-admin-pages";

export default function ShippingQuoteTesterRoute() {
  return <ShippingQuoteTesterPage />;
}
