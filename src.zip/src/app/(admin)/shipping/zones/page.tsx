import { ShippingZonesPage } from "@/features/resources/remaining-admin-pages";

export default function ShippingZonesRoute() {
  return <ShippingZonesPage />;
}
