import { PromotionsPage } from "@/features/resources/admin-resource-pages";

export default function PromotionsRoute() {
  return <PromotionsPage />;
}
