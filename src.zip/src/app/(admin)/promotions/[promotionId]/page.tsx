import { PromotionDetailPage } from "@/features/resources/remaining-admin-pages";

export default async function PromotionDetailRoute({
  params,
}: {
  params: Promise<{ promotionId: string }>;
}) {
  const { promotionId } = await params;

  return <PromotionDetailPage promotionId={promotionId} />;
}
