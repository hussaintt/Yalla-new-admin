import { PromotionCreatePage } from "@/features/resources/remaining-admin-pages";

export default function PromotionCreateRoute() {
  return <PromotionCreatePage />;
}
