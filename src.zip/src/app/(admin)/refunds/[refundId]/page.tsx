import { RefundDetailPage } from "@/features/resources/remaining-admin-pages";

export default async function RefundDetailRoute({
  params,
}: {
  params: Promise<{ refundId: string }>;
}) {
  const { refundId } = await params;

  return <RefundDetailPage refundId={refundId} />;
}
