import { RefundsPage } from "@/features/resources/admin-resource-pages";

export default function RefundsRoute() {
  return <RefundsPage />;
}
