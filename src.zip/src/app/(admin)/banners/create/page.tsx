import { BannerCreatePage } from "@/features/resources/remaining-admin-pages";

export default function BannerCreateRoute() {
  return <BannerCreatePage />;
}
