import { BannerDetailPage } from "@/features/resources/remaining-admin-pages";

export default async function BannerDetailRoute({
  params,
}: {
  params: Promise<{ bannerId: string }>;
}) {
  const { bannerId } = await params;

  return <BannerDetailPage bannerId={bannerId} />;
}
