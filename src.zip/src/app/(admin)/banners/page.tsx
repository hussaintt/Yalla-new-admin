import { BannersPage } from "@/features/resources/admin-resource-pages";

export default function BannersRoute() {
  return <BannersPage />;
}
