import { Suspense } from "react";

import { LoadingState } from "@/components/state/async-states";
import ReviewsPage from "@/features/reviews/reviews-page";

export default function ReviewsRoute() {
  return (
    <Suspense fallback={<LoadingState label="جار تحميل المراجعات" />}>
      <ReviewsPage />
    </Suspense>
  );
}
