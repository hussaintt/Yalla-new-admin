import Link from "next/link";

import { EmptyState } from "@/components/state/async-states";

export default async function ReviewDetailRoute({
  params,
}: {
  params: Promise<{ reviewId: string }>;
}) {
  const { reviewId } = await params;

  return (
    <div className="space-y-4">
      <Link
        href="/reviews"
        className="inline-flex rounded-md border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100"
      >
        كل المراجعات
      </Link>
      <EmptyState
        title="تفاصيل المراجعة تحتاج endpoint من الخلفية"
        description={`المراجعة ${reviewId} تظهر في قائمة /v1/admin/reviews ويمكن اعتمادها أو رفضها من هناك. لا توجد حاليا GET /v1/admin/reviews/:reviewId لصفحة تفاصيل مستقلة.`}
      />
    </div>
  );
}
