import { StoreCategoryDetailPage } from "@/features/resources/remaining-admin-pages";

export default async function StoreCategoryDetailRoute({
  params,
}: {
  params: Promise<{ storeCategoryId: string }>;
}) {
  const { storeCategoryId } = await params;

  return <StoreCategoryDetailPage storeCategoryId={storeCategoryId} />;
}
