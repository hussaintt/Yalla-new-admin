import { CatalogStoreCategoriesPage } from "@/features/resources/remaining-admin-pages";

export default function CatalogStoreCategoriesRoute() {
  return <CatalogStoreCategoriesPage />;
}
