import { CatalogBrandsPage } from "@/features/resources/remaining-admin-pages";

export default function CatalogBrandsRoute() {
  return <CatalogBrandsPage />;
}
