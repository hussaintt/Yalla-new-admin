import { BrandDetailPage } from "@/features/resources/remaining-admin-pages";

export default async function BrandDetailRoute({
  params,
}: {
  params: Promise<{ brandId: string }>;
}) {
  const { brandId } = await params;

  return <BrandDetailPage brandId={brandId} />;
}
