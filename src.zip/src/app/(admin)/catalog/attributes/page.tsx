import { CatalogAttributesIndexPage } from "@/features/resources/remaining-admin-pages";

export default function CatalogAttributesRoute() {
  return <CatalogAttributesIndexPage />;
}
