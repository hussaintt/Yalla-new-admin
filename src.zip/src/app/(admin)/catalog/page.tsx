import { CatalogPage } from "@/features/resources/admin-resource-pages";

export default function CatalogRoute() {
  return <CatalogPage />;
}
