import { CategoryDetailPage } from "@/features/resources/admin-resource-pages";

export default async function CategoryDetailRoute({
  params,
}: {
  params: Promise<{ categoryId: string }>;
}) {
  const { categoryId } = await params;

  return <CategoryDetailPage categoryId={categoryId} />;
}
