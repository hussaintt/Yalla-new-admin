import { OrdersPage } from "@/features/resources/admin-resource-pages";

export default function OrdersRoute() {
  return <OrdersPage />;
}
