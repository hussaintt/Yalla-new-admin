import { BillingGapPage } from "@/features/resources/remaining-admin-pages";

export default function BillingInvoicesRoute() {
  return <BillingGapPage title="فواتير البائعين" />;
}
