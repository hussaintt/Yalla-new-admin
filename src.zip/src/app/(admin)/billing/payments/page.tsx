import { BillingGapPage } from "@/features/resources/remaining-admin-pages";

export default function BillingPaymentsRoute() {
  return <BillingGapPage title="مدفوعات فوترة البائعين" />;
}
