import { BillingPage } from "@/features/resources/admin-resource-pages";

export default function BillingRoute() {
  return <BillingPage />;
}
