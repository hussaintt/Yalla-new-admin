import { AuditLogsPage } from "@/features/resources/admin-resource-pages";

export default function AuditLogsRoute() {
  return <AuditLogsPage />;
}
