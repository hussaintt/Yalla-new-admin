import { AuditLogDetailPage } from "@/features/resources/remaining-admin-pages";

export default async function AuditLogDetailRoute({
  params,
}: {
  params: Promise<{ auditLogId: string }>;
}) {
  const { auditLogId } = await params;

  return <AuditLogDetailPage auditLogId={auditLogId} />;
}
