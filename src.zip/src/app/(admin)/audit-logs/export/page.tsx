import { AuditExportPage } from "@/features/resources/remaining-admin-pages";

export default function AuditExportRoute() {
  return <AuditExportPage />;
}
