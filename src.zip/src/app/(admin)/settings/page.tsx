import { SettingsPage } from "@/features/resources/admin-resource-pages";

export default function SettingsRoute() {
  return <SettingsPage />;
}
