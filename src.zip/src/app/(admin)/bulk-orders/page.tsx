import { BulkOrdersPage } from "@/features/resources/admin-resource-pages";

export default function BulkOrdersRoute() {
  return <BulkOrdersPage />;
}
