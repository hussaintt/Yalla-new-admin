import { BulkOrderDetailPage } from "@/features/resources/remaining-admin-pages";

export default async function BulkOrderDetailRoute({
  params,
}: {
  params: Promise<{ bulkOrderId: string }>;
}) {
  const { bulkOrderId } = await params;

  return <BulkOrderDetailPage bulkOrderId={bulkOrderId} />;
}
