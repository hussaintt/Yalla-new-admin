import { PaymentsPage } from "@/features/resources/admin-resource-pages";

export default function PaymentsRoute() {
  return <PaymentsPage />;
}
