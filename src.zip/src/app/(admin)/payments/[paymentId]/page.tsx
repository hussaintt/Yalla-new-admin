import { PaymentDetailPage } from "@/features/resources/admin-resource-pages";

export default async function PaymentDetailRoute({
  params,
}: {
  params: Promise<{ paymentId: string }>;
}) {
  const { paymentId } = await params;

  return <PaymentDetailPage paymentId={paymentId} />;
}
