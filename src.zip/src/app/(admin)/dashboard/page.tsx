"use client";

import { useQuery } from "@tanstack/react-query";
import {
  Activity,
  BarChart3,
  Clock,
  PackageSearch,
  ShieldCheck,
  Store,
  Users,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { PageHeader } from "@/components/layout/page-header";
import { ErrorState, LoadingState } from "@/components/state/async-states";
import { StatusBadge } from "@/components/status/status-badge";
import { adminApi } from "@/lib/api/admin-client";
import { queryKeys } from "@/lib/api/query-keys";
import type {
  AnalyticsOverview,
  AuditLogPage,
  QueueSnapshot,
  TopProductRow,
  VendorRankingRow,
} from "@/lib/api/types";
import { formatDate, formatMoney, localizedText } from "@/lib/formatters";

type QueueSummaryRow = {
  name: string;
  waiting?: unknown;
  wait?: unknown;
  failed?: unknown;
  value?: unknown;
};

function queueSummary(snapshot: QueueSnapshot | undefined): QueueSummaryRow[] {
  if (!snapshot) return [];

  if (Array.isArray(snapshot.queues)) {
    return snapshot.queues.slice(0, 5) as QueueSummaryRow[];
  }

  return Object.entries(snapshot)
    .slice(0, 5)
    .map(([name, value]) => ({
      name,
      ...(value && typeof value === "object" ? (value as object) : { value }),
    }));
}

export default function DashboardPage() {
  const overview = useQuery({
    queryKey: queryKeys.dashboard.overview(30),
    queryFn: () =>
      adminApi<AnalyticsOverview>("/api/admin/admin/analytics/overview?days=30"),
  });
  const topProducts = useQuery({
    queryKey: queryKeys.dashboard.topProducts(30, 8),
    queryFn: () =>
      adminApi<TopProductRow[]>(
        "/api/admin/admin/analytics/top-products?days=30&limit=8",
      ),
  });
  const vendorRanking = useQuery({
    queryKey: queryKeys.dashboard.vendorRanking(30, 8),
    queryFn: () =>
      adminApi<VendorRankingRow[]>(
        "/api/admin/admin/analytics/vendor-ranking?days=30&limit=8",
      ),
  });
  const queues = useQuery({
    queryKey: queryKeys.dashboard.queues,
    queryFn: () => adminApi<QueueSnapshot>("/api/admin/admin/ops/queues"),
  });
  const audit = useQuery({
    queryKey: queryKeys.dashboard.auditLogs(8),
    queryFn: () =>
      adminApi<AuditLogPage>("/api/admin/admin/audit-logs?limit=8"),
  });

  if (overview.isLoading) return <LoadingState label="جار تحميل لوحة التحكم" />;
  if (overview.isError) return <ErrorState message={overview.error.message} />;

  const currency = overview.data?.revenue?.currency ?? "EGP";
  const cards = [
    {
      label: "إجمالي الإيرادات",
      value: formatMoney(overview.data?.revenue?.grossCents, currency),
      icon: BarChart3,
      hint: `آخر ${overview.data?.windowDays ?? 30} يوم`,
    },
    {
      label: "الطلبات المدفوعة",
      value: String(overview.data?.orders?.paidInWindow ?? 0),
      icon: ShieldCheck,
      hint: `${overview.data?.orders?.placedInWindow ?? 0} طلبا تم إنشاؤه`,
    },
    {
      label: "بائعون قيد المراجعة",
      value: String(overview.data?.vendors?.pending ?? 0),
      icon: Clock,
      hint: `${overview.data?.vendors?.approved ?? 0} معتمد`,
    },
    {
      label: "مستخدمون جدد",
      value: String(overview.data?.users?.createdInWindow ?? 0),
      icon: Users,
      hint: `${overview.data?.users?.total ?? 0} إجمالي`,
    },
  ];

  const productChart = (topProducts.data ?? []).map((row) => ({
    name: localizedText(row.product?.title, row.product?.slug ?? "منتج", "ar"),
    revenue: Math.round((row.revenueCents ?? 0) / 100),
  }));

  return (
    <div className="space-y-6">
      <PageHeader
        title="لوحة التحكم"
        description="مؤشرات السوق، قوائم الاعتماد، إشارات الإيراد، وآخر نشاط إداري."
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.label}
              className="rounded-md border border-slate-200 bg-white p-5"
            >
              <div className="flex items-center justify-between">
                <div className="text-sm font-medium text-slate-500">
                  {card.label}
                </div>
                <Icon className="h-4 w-4 text-teal-700" />
              </div>
              <div className="mt-3 text-2xl font-semibold">{card.value}</div>
              <div className="mt-1 text-xs text-slate-500">{card.hint}</div>
            </div>
          );
        })}
      </section>

      <section className="grid gap-4 xl:grid-cols-[1.4fr_1fr]">
        <div className="rounded-md border border-slate-200 bg-white p-5">
          <div className="mb-5 flex items-center justify-between">
            <h2 className="text-sm font-semibold">أعلى المنتجات بالإيراد</h2>
            <PackageSearch className="h-4 w-4 text-slate-400" />
          </div>
          {topProducts.isLoading ? (
            <LoadingState label="جار تحميل أعلى المنتجات" />
          ) : topProducts.isError ? (
            <ErrorState message={topProducts.error.message} />
          ) : productChart.length === 0 ? (
            <p className="text-sm text-slate-500">لا توجد مبيعات منتجات بعد.</p>
          ) : (
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={productChart}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" hide />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="revenue" fill="#0f766e" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        <div className="rounded-md border border-slate-200 bg-white p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-semibold">صحة الطوابير</h2>
            <StatusBadge status={queues.isError ? "FAILED" : "ACTIVE"} />
          </div>
          {queues.isLoading ? (
            <LoadingState label="جار تحميل الطوابير" />
          ) : queues.isError ? (
            <ErrorState message={queues.error.message} />
          ) : (
            <div className="space-y-3">
              {queueSummary(queues.data).map((queue, index) => (
                <div
                  key={String(queue.name ?? index)}
                  className="rounded-md border border-slate-100 p-3"
                >
                  <div className="text-sm font-medium">
                    {String(queue.name ?? `طابور ${index + 1}`)}
                  </div>
                  <div className="mt-1 text-xs text-slate-500">
                    انتظار: {String(queue.waiting ?? queue.wait ?? 0)} · فشل:{" "}
                    {String(queue.failed ?? 0)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="grid gap-4 xl:grid-cols-2">
        <div className="rounded-md border border-slate-200 bg-white p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-semibold">ترتيب البائعين</h2>
            <Store className="h-4 w-4 text-slate-400" />
          </div>
          {vendorRanking.isLoading ? (
            <LoadingState label="جار تحميل ترتيب البائعين" />
          ) : vendorRanking.isError ? (
            <ErrorState message={vendorRanking.error.message} />
          ) : (
            <div className="space-y-3">
              {(vendorRanking.data ?? []).map((row) => (
                <div
                  key={row.vendor?.publicId ?? row.vendor?.slug}
                  className="flex items-center justify-between rounded-md border border-slate-100 p-3"
                >
                  <div>
                    <div className="text-sm font-medium">
                      {localizedText(row.vendor?.displayName, row.vendor?.slug, "ar")}
                    </div>
                    <div className="text-xs text-slate-500">
                      {row.splitCount ?? 0} تقسيمات طلب
                    </div>
                  </div>
                  <div className="text-sm font-semibold">
                    {formatMoney(row.totalCents, currency)}
                  </div>
                </div>
              ))}
              {(vendorRanking.data ?? []).length === 0 ? (
                <p className="text-sm text-slate-500">لا توجد مبيعات بائعين بعد.</p>
              ) : null}
            </div>
          )}
        </div>

        <div className="rounded-md border border-slate-200 bg-white p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-semibold">آخر سجلات التدقيق</h2>
            <Activity className="h-4 w-4 text-slate-400" />
          </div>
          {audit.isLoading ? (
            <LoadingState label="جار تحميل سجلات التدقيق" />
          ) : audit.isError ? (
            <ErrorState message={audit.error.message} />
          ) : (
            <div className="space-y-3">
              {(audit.data?.data ?? []).map((entry) => (
                <div key={entry.id} className="rounded-md border border-slate-100 p-3">
                  <div className="text-sm font-medium">
                    {entry.action ?? "إجراء إداري"}
                  </div>
                  <div className="mt-1 text-xs text-slate-500">
                    {entry.actor?.email ?? "النظام"} · {entry.targetType ?? "كيان"} ·{" "}
                    {formatDate(entry.createdAt)}
                  </div>
                </div>
              ))}
              {(audit.data?.data ?? []).length === 0 ? (
                <p className="text-sm text-slate-500">لا توجد سجلات تدقيق بعد.</p>
              ) : null}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
