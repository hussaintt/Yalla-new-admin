import { Suspense } from "react";

import { LoadingState } from "@/components/state/async-states";
import VerificationsPage from "@/features/kyc/verifications-page";

export default function VerificationsRoute() {
  return (
    <Suspense fallback={<LoadingState label="جار تحميل التحقق" />}>
      <VerificationsPage />
    </Suspense>
  );
}
