import { cookies } from "next/headers";
import { NextResponse } from "next/server";

import { getBackendBaseUrl, parseBackendResponse } from "@/lib/api/backend";
import { accessCookieName, clearAuthCookies } from "@/lib/auth/cookies";
import { isAdminUser, type AdminUser } from "@/lib/auth/permissions";

export async function GET() {
  const cookieStore = await cookies();
  const accessToken = cookieStore.get(accessCookieName)?.value;

  if (!accessToken) {
    return NextResponse.json(
      {
        statusCode: 401,
        code: "UNAUTHENTICATED",
        message: "Admin session is missing.",
      },
      { status: 401 },
    );
  }

  const backendResponse = await fetch(`${getBackendBaseUrl()}/v1/me`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });
  const user = (await parseBackendResponse(backendResponse)) as AdminUser | null;

  if (!backendResponse.ok) {
    const response = NextResponse.json(user, { status: backendResponse.status });
    if (backendResponse.status === 401) clearAuthCookies(response);
    return response;
  }

  if (!isAdminUser(user)) {
    return NextResponse.json(
      {
        statusCode: 403,
        code: "ADMIN_ACCESS_REQUIRED",
        message: "This account does not have admin panel access.",
      },
      { status: 403 },
    );
  }

  return NextResponse.json(user);
}
