import { cookies } from "next/headers";
import { NextResponse } from "next/server";

import { getBackendBaseUrl, parseBackendResponse } from "@/lib/api/backend";
import {
  clearAuthCookies,
  refreshCookieName,
  setAuthCookies,
} from "@/lib/auth/cookies";

export async function POST() {
  const cookieStore = await cookies();
  const refreshToken = cookieStore.get(refreshCookieName)?.value;

  if (!refreshToken) {
    return NextResponse.json(
      {
        statusCode: 401,
        code: "UNAUTHENTICATED",
        message: "Refresh token is missing.",
      },
      { status: 401 },
    );
  }

  const backendResponse = await fetch(`${getBackendBaseUrl()}/v1/auth/refresh`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ refreshToken }),
  });
  const payload = (await parseBackendResponse(backendResponse)) as
    | { accessToken?: string; refreshToken?: string }
    | null;

  if (!backendResponse.ok || !payload?.accessToken || !payload.refreshToken) {
    const response = NextResponse.json(payload, { status: backendResponse.status });
    clearAuthCookies(response);
    return response;
  }

  const response = NextResponse.json({ ok: true });
  setAuthCookies(response, {
    accessToken: payload.accessToken,
    refreshToken: payload.refreshToken,
  });

  return response;
}
