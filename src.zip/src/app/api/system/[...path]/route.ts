import { cookies } from "next/headers";
import { NextRequest, NextResponse } from "next/server";

import { getBackendBaseUrl, parseBackendResponse } from "@/lib/api/backend";
import { accessCookieName } from "@/lib/auth/cookies";

const allowedSystemPaths = new Set([
  "health",
  "health/ready",
  "metrics",
  "docs/json",
  "docs/yaml",
]);

type SystemProxyContext = {
  params: Promise<{ path: string[] }>;
};

export async function GET(request: NextRequest, context: SystemProxyContext) {
  const cookieStore = await cookies();
  const accessToken = cookieStore.get(accessCookieName)?.value;

  if (!accessToken) {
    return NextResponse.json(
      {
        statusCode: 401,
        code: "UNAUTHENTICATED",
        message: "Admin session is missing.",
      },
      { status: 401 },
    );
  }

  const { path } = await context.params;
  const systemPath = path.map(encodeURIComponent).join("/");

  if (!allowedSystemPaths.has(systemPath)) {
    return NextResponse.json(
      {
        statusCode: 404,
        code: "SYSTEM_ENDPOINT_NOT_ALLOWED",
        message: "This system endpoint is not exposed through the admin panel.",
      },
      { status: 404 },
    );
  }

  const sourceUrl = new URL(request.url);
  const backendResponse = await fetch(
    `${getBackendBaseUrl()}/${systemPath}${sourceUrl.search}`,
    {
      headers: {
        Accept: request.headers.get("accept") ?? "*/*",
      },
    },
  );
  const payload = await parseBackendResponse(backendResponse);

  return NextResponse.json(payload, { status: backendResponse.status });
}
