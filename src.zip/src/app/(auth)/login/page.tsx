"use client";

import { Lock, Mail } from "lucide-react";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { toast } from "sonner";

import { ApiError, normalizeApiError } from "@/lib/api/errors";

async function parseResponse(response: Response) {
  const text = await response.text();
  if (!text) return null;

  try {
    return JSON.parse(text) as unknown;
  } catch {
    return text;
  }
}

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email: username.trim(), password }),
      });
      const payload = await parseResponse(response);

      if (!response.ok) {
        throw new ApiError(normalizeApiError(payload, response.status));
      }

      toast.success("تم تسجيل الدخول");
      router.replace("/dashboard");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "تعذر تسجيل الدخول.",
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <div className="mx-auto flex min-h-screen w-full max-w-6xl items-center px-6 py-10">
        <section className="grid w-full gap-10 lg:grid-cols-[1fr_440px] lg:items-center">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-teal-300">
              إدارة يلا نيو
            </p>
            <h1 className="mt-4 max-w-2xl text-4xl font-semibold leading-tight lg:text-5xl">
              مركز إدارة العمليات والموافقات والمدفوعات.
            </h1>
            <p className="mt-5 max-w-xl text-base leading-7 text-slate-300">
              سجل الدخول بحساب إداري لإدارة المستخدمين والبائعين والوثائق
              والطلبات والكتالوج والمحتوى التسويقي والفواتير وصحة النظام.
            </p>
          </div>

          <form
            onSubmit={handleSubmit}
            className="rounded-lg border border-white/10 bg-white p-6 text-slate-950 shadow-2xl shadow-black/30"
          >
            <div>
              <h2 className="text-xl font-semibold">تسجيل دخول الإدارة</h2>
              <p className="mt-1 text-sm text-slate-500">
                يتم حفظ الجلسة في ملفات تعريف ارتباط آمنة. يدعم الخادم حاليا البريد الإلكتروني وكلمة المرور.
              </p>
            </div>

            <label className="mt-6 block text-sm font-medium text-slate-700">
              اسم المستخدم / البريد الإلكتروني
              <span className="mt-2 flex h-11 items-center gap-2 rounded-md border border-slate-200 px-3">
                <Mail className="h-4 w-4 text-slate-400" />
                <input
                  value={username}
                  onChange={(event) => setUsername(event.target.value)}
                  type="text"
                  required
                  autoComplete="username"
                  className="w-full border-0 bg-transparent text-sm outline-none"
                  placeholder="admin@example.com"
                />
              </span>
            </label>

            <label className="mt-4 block text-sm font-medium text-slate-700">
              كلمة المرور
              <span className="mt-2 flex h-11 items-center gap-2 rounded-md border border-slate-200 px-3">
                <Lock className="h-4 w-4 text-slate-400" />
                <input
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  type="password"
                  required
                  autoComplete="current-password"
                  className="w-full border-0 bg-transparent text-sm outline-none"
                  placeholder="أدخل كلمة المرور"
                />
              </span>
            </label>

            <button
              type="submit"
              disabled={isSubmitting}
              className="mt-6 flex h-11 w-full items-center justify-center rounded-md bg-teal-700 px-4 text-sm font-semibold text-white transition-colors hover:bg-teal-800 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {isSubmitting ? "جار تسجيل الدخول..." : "تسجيل الدخول"}
            </button>
          </form>
        </section>
      </div>
    </main>
  );
}
