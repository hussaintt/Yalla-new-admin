export type AdminPermission =
  | "dashboard:read"
  | "users:read"
  | "users:write"
  | "roles:write"
  | "vendors:read"
  | "vendors:write"
  | "kyc:review"
  | "orders:read"
  | "orders:write"
  | "reviews:moderate"
  | "payments:read"
  | "refunds:write"
  | "catalog:write"
  | "marketing:write"
  | "billing:write"
  | "settings:write"
  | "audit:read"
  | "ops:read";

export type AdminUser = {
  publicId?: string;
  id?: string | number;
  name?: string;
  fullName?: string;
  email?: string;
  accountType?: string;
  roles?: Array<string | { name?: string; code?: string; slug?: string }>;
  permissions?: string[];
};

const superAdminPermissions: AdminPermission[] = [
  "dashboard:read",
  "users:read",
  "users:write",
  "roles:write",
  "vendors:read",
  "vendors:write",
  "kyc:review",
  "orders:read",
  "orders:write",
  "reviews:moderate",
  "payments:read",
  "refunds:write",
  "catalog:write",
  "marketing:write",
  "billing:write",
  "settings:write",
  "audit:read",
  "ops:read",
];

export function getRoleNames(user: AdminUser | null | undefined) {
  return (user?.roles ?? [])
    .map((role) => {
      if (typeof role === "string") return role;
      return role.code ?? role.name ?? role.slug ?? "";
    })
    .filter(Boolean)
    .map((role) => role.toUpperCase());
}

export function isAdminUser(user: AdminUser | null | undefined) {
  if (!user) return false;
  if (user.accountType === "ADMIN") return true;
  return getRoleNames(user).some((role) => role.includes("ADMIN"));
}

export function permissionsForUser(user: AdminUser | null | undefined) {
  if (!isAdminUser(user)) return [];

  const explicit = (user?.permissions ?? []).filter((permission) =>
    superAdminPermissions.includes(permission as AdminPermission),
  ) as AdminPermission[];

  if (explicit.length > 0) return explicit;
  return superAdminPermissions;
}

export function hasPermission(
  user: AdminUser | null | undefined,
  permission: AdminPermission,
) {
  return permissionsForUser(user).includes(permission);
}
