export function getBackendBaseUrl() {
  const baseUrl = process.env.YALLA_API_BASE_URL;

  if (!baseUrl) {
    throw new Error("YALLA_API_BASE_URL is not configured.");
  }

  return baseUrl.replace(/\/$/, "");
}

export async function parseBackendResponse(response: Response) {
  const text = await response.text();
  if (!text) return null;

  try {
    return JSON.parse(text) as unknown;
  } catch {
    return text;
  }
}
