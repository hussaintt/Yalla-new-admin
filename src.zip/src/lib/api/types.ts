import type { CursorPage } from "@/lib/api/pagination";

export type Role = {
  id: number;
  name: string;
  description?: string | null;
  isSystem?: boolean;
  createdAt?: string;
};

export type UserRole = {
  role?: Role;
  roleId?: number;
};

export type AdminUserRow = {
  id: number;
  publicId: string;
  email?: string | null;
  phone?: string | null;
  firstName?: string | null;
  lastName?: string | null;
  status: string;
  locale?: string | null;
  lastLoginAt?: string | null;
  createdAt?: string;
  roles?: UserRole[];
};

export type AdminVendorRow = {
  id: number;
  publicId: string;
  slug?: string;
  legalName?: string;
  displayName?: unknown;
  email?: string | null;
  phone?: string | null;
  storeType?: string | null;
  status: string;
  approvedAt?: string | null;
  createdAt?: string;
  approvedBy?: { publicId?: string; email?: string } | null;
  _count?: { products?: number; members?: number };
};

export type VendorDetail = AdminVendorRow & {
  description?: unknown;
  reviewCount?: number;
  ratingAverage?: unknown;
  defaultCurrency?: string;
  productCount?: number;
};

export type ReviewRow = {
  publicId: string;
  rating: number;
  vendorRating?: number | null;
  deliveryRating?: number | null;
  title?: string | null;
  body?: string | null;
  status: string;
  helpfulCount?: number;
  vendorReply?: string | null;
  vendorReplyAt?: string | null;
  moderationReason?: string | null;
  moderatedAt?: string | null;
  createdAt?: string;
  user?: {
    publicId?: string;
    firstName?: string | null;
    lastName?: string | null;
  };
  product?: {
    publicId?: string;
    slug?: string;
    title?: unknown;
  };
  vendor?: {
    publicId?: string;
    displayName?: unknown;
  };
};

export type VerificationRow = {
  id: number;
  documentType: string;
  documentNumber?: string | null;
  status: string;
  rejectionReason?: string | null;
  reviewedAt?: string | null;
  createdAt?: string;
  expiresAt?: string | null;
  fileUrl?: string | null;
  frontFileUrl?: string | null;
  backFileUrl?: string | null;
};

export type AuditLogRow = {
  id?: number;
  action?: string;
  targetType?: string;
  targetId?: number;
  createdAt?: string;
  actor?: { publicId?: string; email?: string };
};

export type AnalyticsOverview = {
  windowDays?: number;
  users?: { total?: number; createdInWindow?: number };
  vendors?: { pending?: number; approved?: number };
  orders?: { placedInWindow?: number; paidInWindow?: number };
  revenue?: { grossCents?: number; currency?: string };
};

export type TopProductRow = {
  product?: { publicId?: string; slug?: string; title?: unknown };
  quantity?: number;
  revenueCents?: number;
};

export type VendorRankingRow = {
  vendor?: { publicId?: string; slug?: string; displayName?: unknown; status?: string };
  splitCount?: number;
  totalCents?: number;
  vendorPayoutCents?: number;
  commissionCents?: number;
};

export type QueueSnapshot = Record<string, unknown>;

export type UserPage = CursorPage<AdminUserRow>;
export type VendorPage = CursorPage<AdminVendorRow>;
export type ReviewPage = CursorPage<ReviewRow>;
export type AuditLogPage = CursorPage<AuditLogRow>;
