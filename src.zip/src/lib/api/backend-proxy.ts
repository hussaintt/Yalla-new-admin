import { cookies } from "next/headers";
import { NextRequest, NextResponse } from "next/server";

import {
  accessCookieName,
  clearAuthCookies,
  refreshCookieName,
  setAuthCookies,
} from "@/lib/auth/cookies";
import { getBackendBaseUrl, parseBackendResponse } from "@/lib/api/backend";

const jsonHeaders = {
  "Content-Type": "application/json",
};

type RefreshResult =
  | { ok: true; accessToken: string; refreshToken: string }
  | { ok: false };

function jsonResponse(payload: unknown, status: number) {
  return NextResponse.json(payload, { status });
}

function backendUrl(path: string, search = "") {
  return `${getBackendBaseUrl()}/v1/${path.replace(/^\/+/, "")}${search}`;
}

async function refreshAccessToken(refreshToken: string): Promise<RefreshResult> {
  const response = await fetch(`${getBackendBaseUrl()}/v1/auth/refresh`, {
    method: "POST",
    headers: jsonHeaders,
    body: JSON.stringify({ refreshToken }),
  });

  const payload = (await parseBackendResponse(response)) as
    | { accessToken?: string; refreshToken?: string }
    | null;

  if (!response.ok || !payload?.accessToken || !payload.refreshToken) {
    return { ok: false };
  }

  return {
    ok: true,
    accessToken: payload.accessToken,
    refreshToken: payload.refreshToken,
  };
}

async function requestBody(request: NextRequest) {
  if (request.method === "GET" || request.method === "HEAD") {
    return undefined;
  }

  return request.arrayBuffer();
}

async function forwardRequest(
  request: NextRequest,
  path: string,
  accessToken: string,
) {
  const url = new URL(request.url);
  const headers = new Headers();
  const contentType = request.headers.get("content-type");
  const accept = request.headers.get("accept");
  const requestId = request.headers.get("x-request-id");

  if (contentType) headers.set("content-type", contentType);
  if (accept) headers.set("accept", accept);
  if (requestId) headers.set("x-request-id", requestId);
  headers.set("authorization", `Bearer ${accessToken}`);

  return fetch(backendUrl(path, url.search), {
    method: request.method,
    headers,
    body: await requestBody(request),
  });
}

export async function proxyAdminRequest(
  request: NextRequest,
  pathSegments: string[],
) {
  const cookieStore = await cookies();
  const accessToken = cookieStore.get(accessCookieName)?.value;
  const refreshToken = cookieStore.get(refreshCookieName)?.value;
  const path = pathSegments.map(encodeURIComponent).join("/");

  if (!accessToken) {
    return jsonResponse(
      {
        statusCode: 401,
        code: "UNAUTHENTICATED",
        message: "Admin session is missing.",
      },
      401,
    );
  }

  let backendResponse = await forwardRequest(request, path, accessToken);
  let nextTokens: RefreshResult | null = null;

  if (backendResponse.status === 401 && refreshToken) {
    nextTokens = await refreshAccessToken(refreshToken);

    if (nextTokens.ok) {
      backendResponse = await forwardRequest(request, path, nextTokens.accessToken);
    }
  }

  const payload = await parseBackendResponse(backendResponse);
  const response = jsonResponse(payload, backendResponse.status);

  if (nextTokens?.ok) {
    setAuthCookies(response, {
      accessToken: nextTokens.accessToken,
      refreshToken: nextTokens.refreshToken,
    });
  }

  if (backendResponse.status === 401) {
    clearAuthCookies(response);
  }

  return response;
}
