export const queryKeys = {
  me: ["auth", "me"] as const,
  roles: ["roles"] as const,
  users: (params: Record<string, string | undefined>) =>
    ["users", params] as const,
  vendors: (params: Record<string, string | undefined>) =>
    ["vendors", params] as const,
  vendorDetail: (vendorId: string) => ["vendors", vendorId] as const,
  vendorVerifications: (vendorId: string) =>
    ["vendors", vendorId, "verifications"] as const,
  reviews: (params: Record<string, string | undefined>) =>
    ["reviews", params] as const,
  dashboard: {
    overview: (days: number) => ["dashboard", "overview", days] as const,
    topProducts: (days: number, limit: number) =>
      ["dashboard", "top-products", days, limit] as const,
    vendorRanking: (days: number, limit: number) =>
      ["dashboard", "vendor-ranking", days, limit] as const,
    queues: ["dashboard", "queues"] as const,
    auditLogs: (limit: number) => ["dashboard", "audit-logs", limit] as const,
  },
};
