import { ApiError, normalizeApiError } from "@/lib/api/errors";

type RequestOptions = Omit<RequestInit, "body"> & {
  body?: unknown;
};

async function parseJson(response: Response) {
  const text = await response.text();
  if (!text) return null;

  try {
    return JSON.parse(text) as unknown;
  } catch {
    return text;
  }
}

export async function adminApi<T>(
  path: string,
  options: RequestOptions = {},
): Promise<T> {
  const response = await fetch(path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers ?? {}),
    },
    body:
      options.body === undefined ? undefined : JSON.stringify(options.body),
  });

  const payload = await parseJson(response);

  if (!response.ok) {
    throw new ApiError(normalizeApiError(payload, response.status));
  }

  return payload as T;
}
