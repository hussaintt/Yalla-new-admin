"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { FormEvent, useState } from "react";
import { toast } from "sonner";

import { CursorDataTable } from "@/components/data-table/cursor-data-table";
import { CursorPager } from "@/components/data-table/cursor-pager";
import { TableToolbar } from "@/components/data-table/table-toolbar";
import { PageHeader } from "@/components/layout/page-header";
import { ErrorState, LoadingState } from "@/components/state/async-states";
import { StatusBadge } from "@/components/status/status-badge";
import { adminApi } from "@/lib/api/admin-client";
import { withQuery } from "@/lib/api/paths";
import { queryKeys } from "@/lib/api/query-keys";
import type { AdminUserRow, Role, UserPage } from "@/lib/api/types";
import { formatDate, formatName, roleLabel } from "@/lib/formatters";

const userStatuses = [
  { label: "قيد الانتظار", value: "PENDING" },
  { label: "نشط", value: "ACTIVE" },
  { label: "موقوف", value: "SUSPENDED" },
  { label: "محذوف", value: "DELETED" },
];

function roleNames(user: AdminUserRow) {
  return (user.roles ?? []).map(roleLabel).filter(Boolean);
}

function userRoleId(role: unknown) {
  if (!role || typeof role !== "object") return undefined;
  const record = role as Record<string, unknown>;
  if (typeof record.roleId === "number") return record.roleId;
  if (record.role && typeof record.role === "object") {
    const nested = record.role as Record<string, unknown>;
    if (typeof nested.id === "number") return nested.id;
  }
  return undefined;
}

function RoleAssignment({
  user,
  roles,
}: {
  user: AdminUserRow;
  roles: Role[];
}) {
  const queryClient = useQueryClient();
  const [roleId, setRoleId] = useState("");

  const assignRole = useMutation({
    mutationFn: () =>
      adminApi("/api/admin/roles/assign", {
        method: "POST",
        body: { userId: user.id, roleId: Number(roleId) },
      }),
    onSuccess: async () => {
      toast.success("تم تعيين الدور");
      setRoleId("");
      await queryClient.invalidateQueries({ queryKey: ["users"] });
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "تعذر تعيين الدور");
    },
  });

  const revokeRole = useMutation({
    mutationFn: (nextRoleId: number) =>
      adminApi(`/api/admin/roles/users/${user.id}/roles/${nextRoleId}`, {
        method: "DELETE",
      }),
    onSuccess: async () => {
      toast.success("تم حذف الدور");
      await queryClient.invalidateQueries({ queryKey: ["users"] });
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "تعذر حذف الدور");
    },
  });

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-1">
        {(user.roles ?? []).map((role, index) => {
          const label = roleLabel(role);
          const id = userRoleId(role);
          return (
            <span
              key={`${label}-${index}`}
              className="inline-flex items-center gap-1 rounded-md bg-slate-100 px-2 py-1 text-xs text-slate-700"
            >
              {label}
              {id && label !== "ADMIN" ? (
                <button
                  type="button"
                  onClick={() => revokeRole.mutate(id)}
                  className="text-slate-400 hover:text-red-600"
                  title="حذف الدور"
                >
                  ×
                </button>
              ) : null}
            </span>
          );
        })}
      </div>
      <div className="flex gap-2">
        <select
          value={roleId}
          onChange={(event) => setRoleId(event.target.value)}
          className="h-8 min-w-32 rounded-md border border-slate-200 bg-white px-2 text-xs"
        >
          <option value="">تعيين دور</option>
          {roles.map((role) => (
            <option key={role.id} value={role.id}>
              {role.name}
            </option>
          ))}
        </select>
        <button
          type="button"
          disabled={!roleId || assignRole.isPending}
          onClick={() => assignRole.mutate()}
          className="h-8 rounded-md bg-slate-900 px-2 text-xs font-medium text-white disabled:cursor-not-allowed disabled:opacity-50"
        >
          إضافة
        </button>
      </div>
    </div>
  );
}

function CreateRoleForm() {
  const queryClient = useQueryClient();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  const createRole = useMutation({
    mutationFn: () =>
      adminApi<Role>("/api/admin/roles", {
        method: "POST",
        body: { name, description: description || undefined },
      }),
    onSuccess: async () => {
      toast.success("تم إنشاء الدور");
      setName("");
      setDescription("");
      await queryClient.invalidateQueries({ queryKey: queryKeys.roles });
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "تعذر إنشاء الدور");
    },
  });

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    createRole.mutate();
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="grid gap-3 rounded-md border border-slate-200 bg-white p-4 md:grid-cols-[180px_1fr_auto] md:items-end"
    >
      <label className="block text-sm font-medium text-slate-700">
        اسم الدور
        <input
          value={name}
          onChange={(event) => setName(event.target.value)}
          minLength={2}
          required
          className="mt-1 h-10 w-full rounded-md border border-slate-200 px-3 text-sm outline-none"
          placeholder="SUPPORT_AGENT"
        />
      </label>
      <label className="block text-sm font-medium text-slate-700">
        الوصف
        <input
          value={description}
          onChange={(event) => setDescription(event.target.value)}
          className="mt-1 h-10 w-full rounded-md border border-slate-200 px-3 text-sm outline-none"
          placeholder="وصف اختياري للدور"
        />
      </label>
      <button
        type="submit"
        disabled={createRole.isPending}
        className="inline-flex h-10 items-center justify-center gap-2 rounded-md bg-teal-700 px-4 text-sm font-semibold text-white hover:bg-teal-800 disabled:cursor-not-allowed disabled:opacity-50"
      >
        <Plus className="h-4 w-4" />
        إنشاء دور
      </button>
    </form>
  );
}

export default function UsersPage() {
  const searchParams = useSearchParams();
  const queryParams = {
    q: searchParams.get("q") ?? undefined,
    status: searchParams.get("status") ?? undefined,
    cursor: searchParams.get("cursor") ?? undefined,
    limit: "20",
  };
  const queryClient = useQueryClient();

  const users = useQuery({
    queryKey: queryKeys.users(queryParams),
    queryFn: () =>
      adminApi<UserPage>(withQuery("/api/admin/admin/users", queryParams)),
  });

  const roles = useQuery({
    queryKey: queryKeys.roles,
    queryFn: () => adminApi<Role[]>("/api/admin/roles"),
  });

  const updateStatus = useMutation({
    mutationFn: ({ userId, status }: { userId: string; status: string }) =>
      adminApi(`/api/admin/admin/users/${userId}/status`, {
        method: "PATCH",
        body: { status },
      }),
    onSuccess: async () => {
      toast.success("تم تحديث حالة المستخدم");
      await queryClient.invalidateQueries({ queryKey: ["users"] });
      await queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.overview(30) });
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "تعذر تحديث المستخدم");
    },
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="المستخدمون"
        description="البحث عن المستخدمين، مراجعة الأدوار، وإيقاف أو إعادة تنشيط الحسابات."
      />

      <CreateRoleForm />

      <TableToolbar
        searchPlaceholder="ابحث بالاسم أو البريد أو الهاتف"
        statusOptions={userStatuses}
      />

      {users.isLoading || roles.isLoading ? (
        <LoadingState label="جار تحميل المستخدمين" />
      ) : users.isError ? (
        <ErrorState message={users.error.message} />
      ) : roles.isError ? (
        <ErrorState message={roles.error.message} />
      ) : (
        <>
          <CursorDataTable
            data={users.data?.data ?? []}
            getRowKey={(user) => user.publicId}
            columns={[
              {
                id: "user",
                header: "المستخدم",
                cell: (user) => (
                  <div>
                    <Link href={`/users/${user.publicId}`} className="font-medium text-teal-800 hover:underline">{formatName(user)}</Link>
                    <div className="text-xs text-slate-500">{user.email}</div>
                    <div className="text-xs text-slate-500">{user.phone ?? "-"}</div>
                  </div>
                ),
              },
              {
                id: "status",
                header: "الحالة",
                cell: (user) => <StatusBadge status={user.status} />,
              },
              {
                id: "roles",
                header: "الأدوار",
                cell: (user) => (
                  <RoleAssignment user={user} roles={roles.data ?? []} />
                ),
              },
              {
                id: "activity",
                header: "النشاط",
                cell: (user) => (
                  <div className="text-sm text-slate-600">
                    <div>تم الإنشاء {formatDate(user.createdAt)}</div>
                    <div>آخر دخول {formatDate(user.lastLoginAt)}</div>
                    <div>{roleNames(user).length} أدوار</div>
                  </div>
                ),
              },
              {
                id: "actions",
                header: "إجراءات",
                cell: (user) => {
                  const nextStatus =
                    user.status === "SUSPENDED" ? "ACTIVE" : "SUSPENDED";
                  return (
                    <button
                      type="button"
                      disabled={updateStatus.isPending}
                      onClick={() => {
                        const ok = window.confirm(
                          `${nextStatus === "SUSPENDED" ? "إيقاف" : "إعادة تنشيط"} ${user.email ?? user.publicId}؟`,
                        );
                        if (ok) {
                          updateStatus.mutate({
                            userId: user.publicId,
                            status: nextStatus,
                          });
                        }
                      }}
                      className="rounded-md border border-slate-200 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {nextStatus === "SUSPENDED" ? "إيقاف" : "إعادة تنشيط"}
                    </button>
                  );
                },
              },
            ]}
          />
          <CursorPager
            nextCursor={users.data?.nextCursor}
            hasMore={users.data?.hasMore}
          />
        </>
      )}
    </div>
  );
}
