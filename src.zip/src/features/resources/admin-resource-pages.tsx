"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { FormEvent, useMemo, useState } from "react";
import { toast } from "sonner";

import { CursorDataTable } from "@/components/data-table/cursor-data-table";
import { ImageUploadInput } from "@/components/image-upload-input";
import { PageHeader } from "@/components/layout/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/state/async-states";
import { StatusBadge } from "@/components/status/status-badge";
import { adminApi } from "@/lib/api/admin-client";
import { withQuery } from "@/lib/api/paths";
import type { CursorPage } from "@/lib/api/pagination";
import { formatDate, formatMoney, localizedText } from "@/lib/formatters";
import { Switch } from "@/components/ui-switch";
import { ClickableImage } from "@/components/clickable-image";

type AnyRecord = Record<string, unknown>;

function text(value: unknown, fallback = "-") {
  if (value === null || value === undefined || value === "") return fallback;
  if (typeof value === "object") return localizedText(value, fallback, "ar");
  return String(value);
}

function idOf(row: AnyRecord) {
  return String(row.publicId ?? row.id ?? row.key ?? Math.random());
}

function PageCard({ children }: { children: React.ReactNode }) {
  return <div className="rounded-md border border-slate-200 bg-white p-4">{children}</div>;
}

function DetailGrid({ rows }: { rows: Array<{ label: string; value: React.ReactNode }> }) {
  return (
    <PageCard>
      <dl className="grid gap-4 md:grid-cols-3">
        {rows.map((row) => (
          <div key={row.label}>
            <dt className="text-xs font-semibold text-slate-500">{row.label}</dt>
            <dd className="mt-1 text-sm text-slate-900">{row.value}</dd>
          </div>
        ))}
      </dl>
    </PageCard>
  );
}

function BackendGapCard({ title, description }: { title: string; description: string }) {
  return (
    <div className="rounded-md border border-amber-200 bg-amber-50 p-4 text-sm">
      <div className="font-semibold text-amber-900">{title}</div>
      <p className="mt-2 leading-6 text-amber-800">{description}</p>
    </div>
  );
}

function ResourceList<T extends AnyRecord>({
  title,
  description,
  path,
  query,
  columns,
  emptyTitle = "لا توجد بيانات",
  normalize,
}: {
  title: string;
  description: string;
  path: string;
  query?: Record<string, string | undefined>;
  columns: Array<{ id: string; header: React.ReactNode; cell: (row: T) => React.ReactNode }>;
  emptyTitle?: string;
  normalize?: (payload: unknown) => T[] | CursorPage<T>;
}) {
  const [cursor, setCursor] = useState<string | undefined>();
  const params = { limit: "20", cursor, ...(query ?? {}) };
  const url = withQuery(path, params);
  const list = useQuery({
    queryKey: [path, params],
    queryFn: () => adminApi<unknown>(url),
  });

  const result = useMemo(() => {
    if (!list.data) return { data: [] as T[], hasMore: false, nextCursor: null };
    const normalized = normalize?.(list.data);
    if (Array.isArray(normalized)) {
      return { data: normalized, hasMore: false, nextCursor: null };
    }
    if (normalized) return normalized;
    if (Array.isArray(list.data)) return { data: list.data as T[], hasMore: false, nextCursor: null };
    const page = list.data as CursorPage<T>;
    return { data: page.data ?? [], hasMore: page.hasMore, nextCursor: page.nextCursor };
  }, [list.data, normalize]);

  return (
    <div className="space-y-4">
      <PageHeader title={title} description={description} />
      {list.isLoading ? (
        <LoadingState label="جار تحميل البيانات" />
      ) : list.isError ? (
        <ErrorState message={list.error.message} />
      ) : result.data.length === 0 ? (
        <EmptyState title={emptyTitle} description="لا توجد عناصر مطابقة حاليا." />
      ) : (
        <>
          <CursorDataTable data={result.data} getRowKey={(row) => idOf(row)} columns={columns} />
          <div className="flex justify-end gap-2">
            <button
              type="button"
              disabled={!cursor}
              onClick={() => setCursor(undefined)}
              className="rounded-md border border-slate-200 px-3 py-2 text-sm disabled:opacity-50"
            >
              الأولى
            </button>
            <button
              type="button"
              disabled={!result.hasMore || !result.nextCursor}
              onClick={() => setCursor(result.nextCursor ?? undefined)}
              className="rounded-md border border-slate-200 px-3 py-2 text-sm disabled:opacity-50"
            >
              التالي
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function TextInput({
  label,
  value,
  onChange,
  placeholder,
  required,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <label className="block text-sm font-medium text-slate-700">
      {label}
      <input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        required={required}
        placeholder={placeholder}
        className="mt-1 h-10 w-full rounded-md border border-slate-200 px-3 text-sm outline-none"
      />
    </label>
  );
}

export function OrdersPage() {
  const [status, setStatus] = useState("");
  return (
    <div className="space-y-4">
      <PageHeader title="الطلبات" description="متابعة طلبات التجزئة وحالات الدفع والتسليم." />
      <select value={status} onChange={(e) => setStatus(e.target.value)} className="h-10 rounded-md border border-slate-200 bg-white px-3 text-sm">
        <option value="">كل الحالات</option>
        {["PENDING", "CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED", "RETURNED"].map((s) => <option key={s} value={s}>{s}</option>)}
      </select>
      <ResourceList<AnyRecord>
        title=""
        description=""
        path="/api/admin/admin/orders"
        query={{ status: status || undefined }}
        columns={[
          { id: "order", header: "الطلب", cell: (row) => <Link className="font-medium text-teal-800 hover:underline" href={`/orders/${idOf(row)}`}>{text(row.publicId)}</Link> },
          { id: "status", header: "الحالة", cell: (row) => <StatusBadge status={text(row.status, "UNKNOWN")} /> },
          { id: "payment", header: "الدفع", cell: (row) => <StatusBadge status={text(row.paymentStatus, "UNKNOWN")} /> },
          { id: "total", header: "الإجمالي", cell: (row) => formatMoney(row.totalCents, text(row.currency, "EGP")) },
          { id: "date", header: "التاريخ", cell: (row) => formatDate(row.placedAt ?? row.createdAt) },
        ]}
      />
    </div>
  );
}

export function OrderDetailPage({ orderId }: { orderId: string }) {
  const order = useQuery({
    queryKey: ["/api/admin/admin/orders", orderId],
    queryFn: () => adminApi<AnyRecord>(`/api/admin/admin/orders/${orderId}`),
  });
  const payments = useQuery({
    queryKey: ["/api/admin/orders", orderId, "payments"],
    queryFn: () => adminApi<AnyRecord[]>(`/api/admin/orders/${orderId}/payments`),
    retry: false,
  });
  const row = order.data;
  const items = Array.isArray(row?.items) ? row.items as AnyRecord[] : [];
  const splits = Array.isArray(row?.splits) ? row.splits as AnyRecord[] : Array.isArray(row?.orderSplits) ? row.orderSplits as AnyRecord[] : [];

  return (
    <div className="space-y-6">
      <PageHeader
        title={`تفاصيل الطلب ${orderId}`}
        description="عرض بيانات الطلب، العناصر، المدفوعات، وتقسيمات البائعين عند توفرها من الخلفية."
        actions={<Link href="/orders" className="rounded-md border border-slate-200 px-3 py-2 text-sm font-medium hover:bg-slate-100">كل الطلبات</Link>}
      />
      {order.isLoading ? (
        <LoadingState label="جار تحميل الطلب" />
      ) : order.isError ? (
        <ErrorState message={order.error.message} />
      ) : row ? (
        <>
          <DetailGrid rows={[
            { label: "المعرف", value: text(row.publicId) },
            { label: "الحالة", value: <StatusBadge status={text(row.status, "UNKNOWN")} /> },
            { label: "الدفع", value: <StatusBadge status={text(row.paymentStatus, "UNKNOWN")} /> },
            { label: "الإجمالي", value: formatMoney(row.totalCents, text(row.currency, "EGP")) },
            { label: "المشتري", value: text((row.user as AnyRecord | undefined)?.email ?? (row.customer as AnyRecord | undefined)?.email) },
            { label: "تاريخ الطلب", value: formatDate(row.placedAt ?? row.createdAt) },
          ]} />
          <PageCard>
            <div className="mb-3 text-sm font-semibold">عناصر الطلب</div>
            <CursorDataTable data={items} getRowKey={(item) => idOf(item)} columns={[
              {
                id: "product",
                header: "المنتج",
                cell: (item) => (
                  <div className="flex items-center gap-3">
                    {item.imageUrl ? (
                      <div className="h-10 w-10 shrink-0 overflow-hidden rounded border border-slate-200">
                        <ClickableImage src={String(item.imageUrl)} alt={localizedText((item.product as AnyRecord | undefined)?.title, "Product", "ar")} className="h-full w-full object-cover" />
                      </div>
                    ) : null}
                    <div>
                      <div>{localizedText((item.product as AnyRecord | undefined)?.title, text(item.productId), "ar")}</div>
                      {Boolean(item.variantName) && (
                        <div className="text-xs text-slate-400">
                          {localizedText(item.variantName, "", "ar")}
                        </div>
                      )}
                    </div>
                  </div>
                )
              },
              { id: "vendor", header: "البائع", cell: (item) => localizedText((item.vendor as AnyRecord | undefined)?.displayName, text(item.vendorId), "ar") },
              { id: "qty", header: "الكمية", cell: (item) => text(item.quantity, "0") },
              { id: "price", header: "السعر", cell: (item) => formatMoney(item.unitPriceCents ?? item.priceCents, text(row.currency, "EGP")) },
              { id: "total", header: "الإجمالي", cell: (item) => formatMoney(item.totalCents, text(row.currency, "EGP")) },
            ]} />
          </PageCard>
          <PageCard>
            <div className="mb-3 text-sm font-semibold">مدفوعات الطلب</div>
            {payments.isLoading ? <LoadingState label="جار تحميل المدفوعات" /> : payments.isError ? <ErrorState message={payments.error.message} /> : (
              <CursorDataTable data={payments.data ?? []} getRowKey={(payment) => idOf(payment)} columns={[
                { id: "id", header: "الدفع", cell: (payment) => <Link href={`/payments/${idOf(payment)}`} className="font-medium text-teal-800 hover:underline">{text(payment.publicId)}</Link> },
                { id: "status", header: "الحالة", cell: (payment) => <StatusBadge status={text(payment.status, "UNKNOWN")} /> },
                { id: "gateway", header: "البوابة", cell: (payment) => text(payment.gateway) },
                { id: "amount", header: "المبلغ", cell: (payment) => formatMoney(payment.amountCents, text(payment.currency, "EGP")) },
              ]} />
            )}
          </PageCard>
          <PageCard>
            <div className="mb-3 text-sm font-semibold">تقسيمات البائعين</div>
            <CursorDataTable data={splits} getRowKey={(split) => idOf(split)} columns={[
              { id: "vendor", header: "البائع", cell: (split) => localizedText((split.vendor as AnyRecord | undefined)?.displayName, text(split.vendorId), "ar") },
              { id: "status", header: "الحالة", cell: (split) => <StatusBadge status={text(split.status, "UNKNOWN")} /> },
              { id: "fulfillment", header: "الوفاء", cell: (split) => <StatusBadge status={text(split.fulfillmentStatus, "UNKNOWN")} /> },
              { id: "amount", header: "المبلغ", cell: (split) => formatMoney(split.totalCents, text(row.currency, "EGP")) },
            ]} />
          </PageCard>
          <BackendGapCard
            title="إجراءات الطلب الإدارية تحتاج backend"
            description="تحديث الحالة، الإلغاء الإداري، الملاحظات، والخط الزمني تحتاج endpoints مثل /v1/admin/orders/:orderId/status و /v1/admin/orders/:orderId/events."
          />
        </>
      ) : null}
    </div>
  );
}

export function BulkOrdersPage() {
  return (
    <ResourceList<AnyRecord>
      title="طلبات الجملة"
      description="عرض طلبات الجملة الحالية. إجراءات الإدارة المتقدمة تحتاج نقاط /v1/admin/bulk-orders."
      path="/api/admin/bulk/orders"
      columns={[
        { id: "order", header: "الطلب", cell: (row) => <Link href={`/bulk-orders/${idOf(row)}`} className="font-medium text-teal-800 hover:underline">{text(row.publicId)}</Link> },
        { id: "status", header: "الحالة", cell: (row) => <StatusBadge status={text(row.status, "UNKNOWN")} /> },
        { id: "payment", header: "الدفع", cell: (row) => <StatusBadge status={text(row.paymentStatus, "UNKNOWN")} /> },
        { id: "total", header: "الإجمالي", cell: (row) => formatMoney(row.totalCents, text(row.currency, "EGP")) },
        { id: "date", header: "التاريخ", cell: (row) => formatDate(row.createdAt) },
      ]}
    />
  );
}

export function PaymentsPage() {
  const queryClient = useQueryClient();
  const refund = useMutation({
    mutationFn: ({ paymentId, amountCents, reason }: { paymentId: string; amountCents?: number; reason?: string }) =>
      adminApi(`/api/admin/admin/payments/${paymentId}/refund`, {
        method: "POST",
        headers: { "Idempotency-Key": `admin-refund-${paymentId}-${Date.now()}` },
        body: { amountCents, reason },
      }),
    onSuccess: async () => {
      toast.success("تم إنشاء طلب الاسترداد");
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/admin/payments"] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر تنفيذ الاسترداد"),
  });

  return (
    <div className="space-y-4">
      <ResourceList<AnyRecord>
        title="المدفوعات والاسترداد"
        description="مراجعة المدفوعات وتنفيذ استرداد يدوي للمدفوعات المقبوضة."
        path="/api/admin/admin/payments"
        columns={[
          { id: "payment", header: "الدفع", cell: (row) => <div><Link href={`/payments/${idOf(row)}`} className="font-medium text-teal-800 hover:underline">{text(row.publicId)}</Link><div className="text-xs text-slate-500">{text(row.gateway)} · {text(row.method)}</div></div> },
          { id: "status", header: "الحالة", cell: (row) => <StatusBadge status={text(row.status, "UNKNOWN")} /> },
          { id: "amount", header: "المبلغ", cell: (row) => formatMoney(row.amountCents, text(row.currency, "EGP")) },
          { id: "refunded", header: "المسترد", cell: (row) => formatMoney(row.refundedAmountCents, text(row.currency, "EGP")) },
          { id: "date", header: "التاريخ", cell: (row) => formatDate(row.createdAt) },
          { id: "action", header: "إجراء", cell: (row) => <button className="rounded-md border border-red-200 px-2 py-1 text-xs text-red-700 disabled:opacity-50" disabled={refund.isPending} onClick={() => { const reason = window.prompt("سبب الاسترداد"); if (reason) refund.mutate({ paymentId: idOf(row), reason }); }}>استرداد</button> },
        ]}
      />
      <BackendGapCard
        title="قائمة الاستردادات غير متاحة بعد"
        description="الخلفية توفر إنشاء الاسترداد داخل /v1/admin/payments/:paymentId/refund وتعيد الاستردادات ضمن تفاصيل الدفع، لكنها لا توفر حتى الآن endpoint مستقل لقائمة كل الاستردادات أو مراجعتها."
      />
    </div>
  );
}

export function PaymentDetailPage({ paymentId }: { paymentId: string }) {
  const queryClient = useQueryClient();
  const payment = useQuery({
    queryKey: ["/api/admin/payments", paymentId],
    queryFn: () => adminApi<AnyRecord>(`/api/admin/payments/${paymentId}`),
  });
  const refund = useMutation({
    mutationFn: ({ amountCents, reason }: { amountCents?: number; reason?: string }) =>
      adminApi(`/api/admin/admin/payments/${paymentId}/refund`, {
        method: "POST",
        headers: { "Idempotency-Key": `admin-refund-${paymentId}-${Date.now()}` },
        body: { amountCents, reason },
      }),
    onSuccess: async () => {
      toast.success("تم إنشاء الاسترداد");
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/payments", paymentId] });
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/admin/payments"] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر تنفيذ الاسترداد"),
  });

  const row = payment.data;
  const refunds = Array.isArray(row?.refunds) ? row.refunds as AnyRecord[] : [];

  return (
    <div className="space-y-6">
      <PageHeader
        title={`تفاصيل الدفع ${paymentId}`}
        description="عرض حالة الدفع، بيانات البوابة، والاستردادات المرتبطة به."
        actions={<Link href="/payments" className="rounded-md border border-slate-200 px-3 py-2 text-sm font-medium hover:bg-slate-100">كل المدفوعات</Link>}
      />
      {payment.isLoading ? (
        <LoadingState label="جار تحميل الدفع" />
      ) : payment.isError ? (
        <ErrorState message={payment.error.message} />
      ) : row ? (
        <>
          <DetailGrid rows={[
            { label: "المعرف", value: text(row.publicId) },
            { label: "الحالة", value: <StatusBadge status={text(row.status, "UNKNOWN")} /> },
            { label: "المبلغ", value: formatMoney(row.amountCents, text(row.currency, "EGP")) },
            { label: "المسترد", value: formatMoney(row.refundedAmountCents, text(row.currency, "EGP")) },
            { label: "البوابة", value: text(row.gateway) },
            { label: "الطريقة", value: text(row.method) },
            { label: "الطلب", value: text(row.orderId ?? (row.order as AnyRecord | undefined)?.publicId) },
            { label: "معرف معاملة البوابة", value: text(row.gatewayTransactionId) },
            { label: "تاريخ الإنشاء", value: formatDate(row.createdAt) },
          ]} />
          <PageCard>
            <div className="mb-3 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-semibold">الاستردادات</div>
                <p className="mt-1 text-sm text-slate-500">تظهر هنا الاستردادات التي تعيدها تفاصيل الدفع من الخلفية.</p>
              </div>
              <button
                type="button"
                disabled={refund.isPending}
                onClick={() => {
                  const amount = window.prompt("المبلغ بالقروش، اتركه فارغا لاسترداد المتبقي");
                  const reason = window.prompt("سبب الاسترداد");
                  if (reason) refund.mutate({ amountCents: amount ? Number(amount) : undefined, reason });
                }}
                className="rounded-md border border-red-200 px-3 py-2 text-sm font-medium text-red-700 disabled:opacity-50"
              >
                إنشاء استرداد
              </button>
            </div>
            <CursorDataTable
              data={refunds}
              getRowKey={(refundRow) => idOf(refundRow)}
              columns={[
                { id: "id", header: "الاسترداد", cell: (refundRow) => text(refundRow.publicId) },
                { id: "amount", header: "المبلغ", cell: (refundRow) => formatMoney(refundRow.amountCents, text(row.currency, "EGP")) },
                { id: "reason", header: "السبب", cell: (refundRow) => text(refundRow.reason) },
                { id: "date", header: "التاريخ", cell: (refundRow) => formatDate(refundRow.createdAt) },
              ]}
            />
          </PageCard>
        </>
      ) : null}
    </div>
  );
}

export function RefundsPage() {
  return (
    <ResourceList<AnyRecord>
      title="الاستردادات"
      description="متابعة طلبات الاسترداد المالي والسجل التاريخي."
      path="/api/admin/admin/refunds"
      columns={[
        { id: "refund", header: "معرف الاسترداد", cell: (row) => text(row.publicId) },
        { id: "amount", header: "المبلغ", cell: (row) => formatMoney(row.amountCents, text(row.currency, "EGP")) },
        { id: "reason", header: "السبب", cell: (row) => text(row.reason) },
        { id: "payment", header: "معرف الدفع المرتبط", cell: (row) => { const payment = row.payment as AnyRecord | undefined; return payment ? <Link className="font-medium text-teal-800 hover:underline" href={`/payments/${payment.publicId}`}>{text(payment.publicId)}</Link> : "-"; } },
        { id: "createdBy", header: "بواسطة", cell: (row) => { const createdBy = row.createdBy as AnyRecord | undefined; return text(createdBy?.email); } },
        { id: "date", header: "التاريخ", cell: (row) => formatDate(row.createdAt) },
      ]}
    />
  );
}

export function ProductsPage() {
  return (
    <ResourceList<AnyRecord>
      title="المنتجات"
      description="فحص المنتجات العامة، الأسعار، البائعين، ومؤشرات المخزون المتاحة من الخلفية."
      path="/api/admin/products"
      columns={[
        { id: "product", header: "المنتج", cell: (row) => <Link className="font-medium text-teal-800 hover:underline" href={`/products/${idOf(row)}`}>{localizedText(row.title, text(row.slug))}</Link> },
        { id: "status", header: "الحالة", cell: (row) => <StatusBadge status={text(row.status, "UNKNOWN")} /> },
        { id: "price", header: "السعر", cell: (row) => formatMoney(row.priceCents ?? row.basePriceCents, text(row.currency, "EGP")) },
        { id: "vendor", header: "البائع", cell: (row) => localizedText((row.vendor as AnyRecord | undefined)?.displayName, text((row.vendor as AnyRecord | undefined)?.slug)) },
        { id: "date", header: "التاريخ", cell: (row) => formatDate(row.createdAt) },
      ]}
    />
  );
}

export function ProductDetailPage({ productId }: { productId: string }) {
  const queryClient = useQueryClient();
  const product = useQuery({
    queryKey: ["/api/admin/products", productId],
    queryFn: () => adminApi<AnyRecord>(`/api/admin/products/${productId}`),
  });
  const availability = useQuery({
    queryKey: ["/api/admin/products", productId, "availability"],
    queryFn: () => adminApi<AnyRecord>(`/api/admin/products/${productId}/availability`),
    retry: false,
  });

  const updateStatus = useMutation({
    mutationFn: (status: "ACTIVE" | "DRAFT" | "ARCHIVED") =>
      adminApi(`/api/admin/admin/products/${productId}/status`, {
        method: "PATCH",
        body: { status },
      }),
    onSuccess: async () => {
      toast.success("تم تحديث حالة المنتج بنجاح");
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/products", productId] });
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "تعذر تحديث حالة المنتج");
    },
  });

  const row = product.data;
  const variants = Array.isArray(row?.variants) ? row.variants as AnyRecord[] : [];
  const images = Array.isArray(row?.images) ? row.images as AnyRecord[] : [];
  const availabilityVariants = Array.isArray(availability.data?.variants) ? availability.data.variants as AnyRecord[] : [];

  return (
    <div className="space-y-6">
      <PageHeader
        title={row ? localizedText(row.title, productId, "ar") : `تفاصيل المنتج ${productId}`}
        description="تفتيش بيانات المنتج، البائع، التصنيف، الصور، المتغيرات، وتوفر المخزون."
        actions={<Link href="/products" className="rounded-md border border-slate-200 px-3 py-2 text-sm font-medium hover:bg-slate-100">كل المنتجات</Link>}
      />
      {product.isLoading ? (
        <LoadingState label="جار تحميل المنتج" />
      ) : product.isError ? (
        <ErrorState message={product.error.message} />
      ) : row ? (
        <>
          <DetailGrid rows={[
            { label: "المعرف", value: text(row.publicId) },
            { label: "Slug", value: text(row.slug) },
            { label: "الحالة", value: <StatusBadge status={text(row.status, "UNKNOWN")} /> },
            { label: "قناة البيع", value: text(row.salesChannel) },
            { label: "السعر", value: formatMoney(row.priceCents ?? row.basePriceCents, text(row.currency, "EGP")) },
            { label: "البائع", value: localizedText((row.vendor as AnyRecord | undefined)?.displayName, text((row.vendor as AnyRecord | undefined)?.slug), "ar") },
            { label: "التصنيف", value: localizedText((row.category as AnyRecord | undefined)?.name, text((row.category as AnyRecord | undefined)?.slug), "ar") },
            { label: "العلامة", value: localizedText((row.brand as AnyRecord | undefined)?.name, text((row.brand as AnyRecord | undefined)?.slug), "ar") },
            { label: "تاريخ الإنشاء", value: formatDate(row.createdAt) },
          ]} />
          {availability.isError ? (
            <BackendGapCard
              title="توفر المخزون غير متاح لهذا المنتج"
              description="نقطة /v1/products/:publicId/availability تعرض المنتجات النشطة من بائعين معتمدين فقط. إذا كان المنتج قيد المراجعة أو موقوفا فلن تعيد بيانات المخزون."
            />
          ) : (
            <DetailGrid rows={[
              { label: "المتاح للبيع", value: availability.isLoading ? "جار الحساب" : text(availability.data?.availableQty, "0") },
              { label: "عدد المتغيرات", value: text(availabilityVariants.length, "0") },
              { label: "حالة المخزون", value: availability.isLoading ? "-" : Number(availability.data?.availableQty ?? 0) > 0 ? "متاح" : "غير متاح" },
            ]} />
          )}
          <PageCard>
            <div className="mb-3 text-sm font-semibold">المتغيرات</div>
            <CursorDataTable
              data={variants.length ? variants : availabilityVariants}
              getRowKey={(variant) => idOf(variant)}
              columns={[
                { id: "sku", header: "SKU", cell: (variant) => text(variant.sku ?? variant.publicId) },
                { id: "status", header: "الحالة", cell: (variant) => <StatusBadge status={variant.isActive === false ? "INACTIVE" : "ACTIVE"} /> },
                { id: "price", header: "السعر", cell: (variant) => formatMoney(variant.priceCents ?? variant.basePriceCents, text(row.currency, "EGP")) },
                { id: "stock", header: "المخزون", cell: (variant) => text(variant.availableQty ?? variant.stockQuantity ?? variant.quantity, "-") },
              ]}
            />
          </PageCard>
          <PageCard>
            <div className="mb-3 text-sm font-semibold">الصور</div>
            {Array.isArray(row.imageUrls) && row.imageUrls.length ? (
              <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
                {(row.imageUrls as string[]).map((url: string, index: number) => (
                  <div key={index} className="relative group aspect-square rounded-md overflow-hidden border border-slate-200 bg-slate-50 shadow-xs">
                    <ClickableImage src={url} alt={`صورة المنتج ${index + 1}`} className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            ) : images.length ? (
              <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
                {images.map((image) => {
                  const imgUrl = String(image.url ?? image.imageUrl ?? image.fileUrl ?? `/api/admin/files/${image.publicId}`);
                  return (
                    <div key={idOf(image)} className="relative group aspect-square rounded-md overflow-hidden border border-slate-200 bg-slate-50 shadow-xs">
                      <ClickableImage src={imgUrl} alt={text(image.altText, "صورة المنتج")} className="w-full h-full object-cover" />
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-slate-500">لا توجد صور معادة من API لهذا المنتج.</p>
            )}
          </PageCard>
          <PageCard>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="text-sm font-semibold">إجراءات الاعتدال والرقابة</div>
                <p className="mt-1 text-xs text-slate-500">تحديث الحالة التشغيلية للمنتج مباشرة في الخلفية.</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={updateStatus.isPending || row.status === "ACTIVE"}
                  onClick={() => updateStatus.mutate("ACTIVE")}
                  className="rounded-md bg-teal-700 px-3 py-2 text-xs font-semibold text-white hover:bg-teal-800 disabled:opacity-50"
                >
                  اعتماد ونشر (Active)
                </button>
                <button
                  type="button"
                  disabled={updateStatus.isPending || row.status === "ARCHIVED"}
                  onClick={() => updateStatus.mutate("ARCHIVED")}
                  className="rounded-md bg-amber-600 px-3 py-2 text-xs font-semibold text-white hover:bg-amber-700 disabled:opacity-50"
                >
                  إيقاف مؤقت (Archived)
                </button>
                <button
                  type="button"
                  disabled={updateStatus.isPending || row.status === "DRAFT"}
                  onClick={() => updateStatus.mutate("DRAFT")}
                  className="rounded-md border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50"
                >
                  إرجاع للمسودة (Draft)
                </button>
              </div>
            </div>
          </PageCard>
        </>
      ) : null}
    </div>
  );
}

function SimpleCreateForm({
  title,
  fields,
  onSubmit,
  pending,
}: {
  title: string;
  fields: Array<{ label: string; value: string; onChange: (value: string) => void; required?: boolean; placeholder?: string }>;
  onSubmit: () => void;
  pending?: boolean;
}) {
  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    onSubmit();
  }
  return (
    <PageCard>
      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="text-sm font-semibold">{title}</div>
        <div className="grid gap-3 md:grid-cols-3">
          {fields.map((field) => (
            <TextInput key={field.label} {...field} />
          ))}
        </div>
        <button disabled={pending} className="rounded-md bg-teal-700 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">
          حفظ
        </button>
      </form>
    </PageCard>
  );
}

export function CatalogPage() {
  const queryClient = useQueryClient();
  const [categoryName, setCategoryName] = useState("");
  const [categorySlug, setCategorySlug] = useState("");
  const [brandName, setBrandName] = useState("");
  const [brandSlug, setBrandSlug] = useState("");
  const [storeName, setStoreName] = useState("");
  const [storeSlug, setStoreSlug] = useState("");

  const createCategory = useMutation({
    mutationFn: () => adminApi("/api/admin/categories", { method: "POST", body: { name: { ar: categoryName, en: categoryName }, slug: categorySlug, isActive: true } }),
    onSuccess: async () => { toast.success("تم إنشاء التصنيف"); setCategoryName(""); setCategorySlug(""); await queryClient.invalidateQueries({ queryKey: ["/api/admin/categories"] }); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذر إنشاء التصنيف"),
  });
  const createBrand = useMutation({
    mutationFn: () => adminApi("/api/admin/brands", { method: "POST", body: { name: { ar: brandName, en: brandName }, slug: brandSlug, isActive: true } }),
    onSuccess: async () => { toast.success("تم إنشاء العلامة"); setBrandName(""); setBrandSlug(""); await queryClient.invalidateQueries({ queryKey: ["/api/admin/brands"] }); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذر إنشاء العلامة"),
  });
  const createStore = useMutation({
    mutationFn: () => adminApi("/api/admin/store-categories", { method: "POST", body: { name: { ar: storeName, en: storeName }, slug: storeSlug, isActive: true } }),
    onSuccess: async () => { toast.success("تم إنشاء تصنيف المتجر"); setStoreName(""); setStoreSlug(""); await queryClient.invalidateQueries({ queryKey: ["/api/admin/store-categories"] }); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذر إنشاء تصنيف المتجر"),
  });

  return (
    <div className="space-y-6">
      <PageHeader title="الكتالوج" description="إدارة التصنيفات والعلامات وتصنيفات المتاجر." />
      <div className="flex flex-wrap gap-2">
        <Link href="/catalog/brands" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">العلامات التجارية</Link>
        <Link href="/catalog/store-categories" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">تصنيفات المتاجر</Link>
        <Link href="/catalog/attributes" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">خصائص التصنيفات</Link>
      </div>
      <SimpleCreateForm title="إضافة تصنيف" pending={createCategory.isPending} onSubmit={() => createCategory.mutate()} fields={[{ label: "الاسم", value: categoryName, onChange: setCategoryName, required: true }, { label: "Slug", value: categorySlug, onChange: setCategorySlug, required: true }]} />
      <ResourceList<AnyRecord> title="التصنيفات" description="" path="/api/admin/categories" query={{ flat: "true", withCounts: "true" }} columns={[
        {
          id: "image",
          header: "الصورة",
          cell: (r) => r.imageUrl ? (
            <div className="h-10 w-10 shrink-0 overflow-hidden rounded border border-slate-200 bg-slate-50">
              <ClickableImage src={String(r.imageUrl)} alt="Category" className="h-full w-full object-cover" />
            </div>
          ) : (
            <span className="text-slate-400 text-xs">-</span>
          )
        },
        { id: "name", header: "الاسم", cell: (r) => <div><Link href={`/catalog/categories/${idOf(r)}`} className="font-medium text-teal-800 hover:underline">{localizedText(r.name, text(r.slug), "ar")}</Link><div className="text-xs text-slate-500">{text(r.slug)}</div></div> },
        { id: "status", header: "الحالة", cell: (r) => <StatusBadge status={r.isActive === false ? "INACTIVE" : "ACTIVE"} /> },
        { id: "count", header: "المنتجات", cell: (r) => text(r.productCount ?? (r._count as AnyRecord | undefined)?.products, "0") },
        { id: "date", header: "التاريخ", cell: (r) => formatDate(r.createdAt) },
      ]} normalize={(p) => Array.isArray(p) ? p as AnyRecord[] : []} />
      <SimpleCreateForm title="إضافة علامة تجارية" pending={createBrand.isPending} onSubmit={() => createBrand.mutate()} fields={[{ label: "الاسم", value: brandName, onChange: setBrandName, required: true }, { label: "Slug", value: brandSlug, onChange: setBrandSlug, required: true }]} />
      <ResourceList<AnyRecord> title="العلامات التجارية" description="" path="/api/admin/brands" columns={[
        { id: "name", header: "الاسم", cell: (r) => localizedText(r.name, text(r.slug)) },
        { id: "status", header: "الحالة", cell: (r) => <StatusBadge status={r.isActive === false ? "INACTIVE" : "ACTIVE"} /> },
        { id: "date", header: "التاريخ", cell: (r) => formatDate(r.createdAt) },
      ]} />
      <SimpleCreateForm title="إضافة تصنيف متجر" pending={createStore.isPending} onSubmit={() => createStore.mutate()} fields={[{ label: "الاسم", value: storeName, onChange: setStoreName, required: true }, { label: "Slug", value: storeSlug, onChange: setStoreSlug, required: true }]} />
      <ResourceList<AnyRecord> title="تصنيفات المتاجر" description="" path="/api/admin/store-categories" columns={[
        { id: "name", header: "الاسم", cell: (r) => localizedText(r.name, text(r.slug)) },
        { id: "status", header: "الحالة", cell: (r) => <StatusBadge status={r.isActive === false ? "INACTIVE" : "ACTIVE"} /> },
        { id: "date", header: "التاريخ", cell: (r) => formatDate(r.createdAt) },
      ]} normalize={(p) => Array.isArray(p) ? p as AnyRecord[] : []} />
    </div>
  );
}

export function CategoryDetailPage({ categoryId }: { categoryId: string }) {
  const queryClient = useQueryClient();
  const [attrKey, setAttrKey] = useState("");
  const [attrLabel, setAttrLabel] = useState("");
  const [attrType, setAttrType] = useState("STRING");
  const [attrUnit, setAttrUnit] = useState("");
  const [attrOptions, setAttrOptions] = useState("");

  const category = useQuery({
    queryKey: ["/api/admin/categories", categoryId],
    queryFn: () => adminApi<AnyRecord>(`/api/admin/categories/${categoryId}`),
  });
  const attributes = useQuery({
    queryKey: ["/api/admin/categories", categoryId, "attributes"],
    queryFn: () => adminApi<AnyRecord[]>(`/api/admin/categories/${categoryId}/attributes`),
  });
  const createAttribute = useMutation({
    mutationFn: () => {
      const options = attrOptions
        ? attrOptions.split(",").map((option) => option.trim()).filter(Boolean)
        : undefined;
      return adminApi(`/api/admin/categories/${categoryId}/attributes`, {
        method: "POST",
        body: {
          key: attrKey,
          labelI18n: { ar: attrLabel, en: attrLabel },
          dataType: attrType,
          unit: attrUnit || undefined,
          options,
          isFilterable: true,
          isVariantAxis: false,
          isRequired: false,
        },
      });
    },
    onSuccess: async () => {
      toast.success("تم إنشاء خاصية التصنيف");
      setAttrKey("");
      setAttrLabel("");
      setAttrUnit("");
      setAttrOptions("");
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/categories", categoryId, "attributes"] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر إنشاء الخاصية"),
  });
  const deleteAttribute = useMutation({
    mutationFn: (attributeId: string) =>
      adminApi(`/api/admin/categories/${categoryId}/attributes/${attributeId}`, { method: "DELETE" }),
    onSuccess: async () => {
      toast.success("تم حذف الخاصية");
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/categories", categoryId, "attributes"] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر حذف الخاصية"),
  });

  const row = category.data;

  return (
    <div className="space-y-6">
      <PageHeader
        title={row ? localizedText(row.name, categoryId, "ar") : `تفاصيل التصنيف ${categoryId}`}
        description="إدارة خصائص التصنيف المستخدمة في فلاتر المنتجات ومتغيراتها."
        actions={<Link href="/catalog" className="rounded-md border border-slate-200 px-3 py-2 text-sm font-medium hover:bg-slate-100">الكتالوج</Link>}
      />
      {category.isLoading ? (
        <LoadingState label="جار تحميل التصنيف" />
      ) : category.isError ? (
        <ErrorState message={category.error.message} />
      ) : row ? (
        <DetailGrid rows={[
          { label: "المعرف", value: text(row.publicId) },
          { label: "Slug", value: text(row.slug) },
          {
            label: "الصورة",
            value: row.imageUrl ? (
              <div className="h-16 w-16 overflow-hidden rounded border border-slate-200 bg-slate-50">
                <ClickableImage src={String(row.imageUrl)} alt="Category" className="h-full w-full object-cover" />
              </div>
            ) : (
              "-"
            )
          },
          { label: "الحالة", value: <StatusBadge status={row.isActive === false ? "INACTIVE" : "ACTIVE"} /> },
          { label: "الترتيب", value: text(row.sortOrder, "0") },
          { label: "تاريخ الإنشاء", value: formatDate(row.createdAt) },
        ]} />
      ) : null}
      <SimpleCreateForm
        title="إضافة خاصية تصنيف"
        pending={createAttribute.isPending}
        onSubmit={() => createAttribute.mutate()}
        fields={[
          { label: "المفتاح", value: attrKey, onChange: setAttrKey, required: true, placeholder: "color" },
          { label: "العنوان", value: attrLabel, onChange: setAttrLabel, required: true },
          { label: "النوع", value: attrType, onChange: setAttrType, required: true, placeholder: "STRING / ENUM / INT" },
          { label: "الوحدة", value: attrUnit, onChange: setAttrUnit },
          { label: "خيارات ENUM مفصولة بفواصل", value: attrOptions, onChange: setAttrOptions },
        ]}
      />
      <PageCard>
        <div className="mb-3 text-sm font-semibold">خصائص التصنيف</div>
        {attributes.isLoading ? (
          <LoadingState label="جار تحميل الخصائص" />
        ) : attributes.isError ? (
          <ErrorState message={attributes.error.message} />
        ) : (
          <CursorDataTable
            data={attributes.data ?? []}
            getRowKey={(attr) => idOf(attr)}
            columns={[
              { id: "key", header: "المفتاح", cell: (attr) => <div><div className="font-medium">{text(attr.key)}</div><div className="text-xs text-slate-500">{localizedText(attr.labelI18n, text(attr.key), "ar")}</div></div> },
              { id: "type", header: "النوع", cell: (attr) => text(attr.dataType) },
              { id: "flags", header: "الاستخدام", cell: (attr) => <div className="text-xs text-slate-600">{attr.isFilterable ? "فلتر" : "بدون فلتر"} · {attr.isVariantAxis ? "محور متغير" : "خاصية منتج"} · {attr.isRequired ? "إجباري" : "اختياري"}</div> },
              { id: "options", header: "الخيارات", cell: (attr) => Array.isArray(attr.options) ? attr.options.join(", ") : text(attr.options) },
              { id: "actions", header: "إجراء", cell: (attr) => <button type="button" disabled={deleteAttribute.isPending} onClick={() => { if (window.confirm("حذف هذه الخاصية؟")) deleteAttribute.mutate(idOf(attr)); }} className="rounded-md border border-red-200 px-2 py-1 text-xs text-red-700 disabled:opacity-50">حذف</button> },
            ]}
          />
        )}
      </PageCard>
    </div>
  );
}

export function PromotionsPage() {
  const queryClient = useQueryClient();
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [valueBps, setValueBps] = useState("1000");
  const create = useMutation({
    mutationFn: () => adminApi("/api/admin/admin/promotions", { method: "POST", body: { code, name: { ar: name, en: name }, discountType: "PERCENTAGE", scope: "PLATFORM", valueBps: Number(valueBps), validFrom: new Date().toISOString(), status: "ACTIVE" } }),
    onSuccess: async () => { toast.success("تم إنشاء العرض"); setCode(""); setName(""); await queryClient.invalidateQueries({ queryKey: ["/api/admin/admin/promotions"] }); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذر إنشاء العرض"),
  });
  return (
    <div className="space-y-6">
      <PageHeader title="العروض" description="إدارة كوبونات المنصة والعروض التسويقية." actions={<Link href="/promotions/create" className="rounded-md bg-teal-700 px-3 py-2 text-sm font-semibold text-white">إنشاء عرض</Link>} />
      <SimpleCreateForm title="إضافة عرض نسبة مئوية" pending={create.isPending} onSubmit={() => create.mutate()} fields={[{ label: "الكود", value: code, onChange: setCode, required: true }, { label: "الاسم", value: name, onChange: setName, required: true }, { label: "النسبة بالنقاط BPS", value: valueBps, onChange: setValueBps, required: true }]} />
      <ResourceList<AnyRecord> title="قائمة العروض" description="" path="/api/admin/admin/promotions" columns={[
        { id: "name", header: "العرض", cell: (r) => <div><Link href={`/promotions/${idOf(r)}`} className="font-medium text-teal-800 hover:underline">{localizedText(r.name, text(r.code), "ar")}</Link><div className="text-xs text-slate-500">{text(r.code)}</div></div> },
        { id: "status", header: "الحالة", cell: (r) => <StatusBadge status={text(r.status, "UNKNOWN")} /> },
        { id: "discount", header: "الخصم", cell: (r) => text(r.discountType) },
        { id: "dates", header: "الصلاحية", cell: (r) => <div>{formatDate(r.validFrom)}<br />{formatDate(r.validUntil)}</div> },
      ]} />
    </div>
  );
}

export function BannersPage() {
  const queryClient = useQueryClient();
  const [imageFileId, setImageFileId] = useState("");
  const [title, setTitle] = useState("");
  const [position, setPosition] = useState("HOME_HERO");
  const create = useMutation({
    mutationFn: () => adminApi("/api/admin/admin/banners", { method: "POST", body: { imageFileId, title: { ar: title, en: title }, position, isActive: true } }),
    onSuccess: async () => { toast.success("تم إنشاء البانر"); setImageFileId(""); setTitle(""); await queryClient.invalidateQueries({ queryKey: ["/api/admin/admin/banners"] }); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذر إنشاء البانر"),
  });
  const toggleActive = useMutation({
    mutationFn: ({ bannerId, isActive }: { bannerId: string; isActive: boolean }) =>
      adminApi(`/api/admin/admin/banners/${bannerId}`, {
        method: "PATCH",
        body: { isActive },
      }),
    onSuccess: async () => {
      toast.success("تم تحديث حالة البانر");
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/admin/banners"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذر تحديث حالة البانر"),
  });
  return (
    <div className="space-y-6">
      <PageHeader title="البانرات" description="إدارة بانرات الصفحة الرئيسية والحملات." actions={<Link href="/banners/create" className="rounded-md bg-teal-700 px-3 py-2 text-sm font-semibold text-white">إنشاء بانر</Link>} />
      
      <PageCard>
        <form onSubmit={(event) => { event.preventDefault(); create.mutate(); }} className="space-y-4">
          <div className="text-sm font-semibold">إضافة بانر</div>
          <div className="grid gap-4 md:grid-cols-2">
            <TextInput label="العنوان" value={title} onChange={setTitle} required />
            <label className="block text-sm font-medium text-slate-700">
              الموضع
              <select value={position} onChange={(e) => setPosition(e.target.value)} className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm outline-none">
                <option value="HOME_HERO">HOME_HERO</option>
                <option value="HOME_STRIP">HOME_STRIP</option>
                <option value="CATEGORY_HEADER">CATEGORY_HEADER</option>
                <option value="CATEGORIES_FEATURED">CATEGORIES_FEATURED</option>
              </select>
            </label>
          </div>
          <ImageUploadInput label="صورة البانر" value={imageFileId} onChange={setImageFileId} purpose="BANNER_IMAGE" required />
          <button disabled={create.isPending || !imageFileId} className="rounded-md bg-teal-700 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50 cursor-pointer">
            حفظ
          </button>
        </form>
      </PageCard>

      <ResourceList<AnyRecord> title="قائمة البانرات" description="" path="/api/admin/admin/banners" columns={[
        {
          id: "image",
          header: "الصورة",
          cell: (r) => r.imageUrl ? (
            <div className="h-10 w-20 shrink-0 overflow-hidden rounded border border-slate-200">
              <ClickableImage src={String(r.imageUrl)} alt={localizedText(r.title, "Banner", "ar")} className="h-full w-full object-cover" />
            </div>
          ) : (
            <span className="text-slate-400 text-xs">-</span>
          )
        },
        { id: "title", header: "العنوان", cell: (r) => <Link href={`/banners/${idOf(r)}`} className="font-medium text-teal-800 hover:underline">{localizedText(r.title, idOf(r), "ar")}</Link> },
        { id: "position", header: "الموضع", cell: (r) => text(r.position) },
        {
          id: "status",
          header: "الحالة",
          cell: (r) => (
            <div className="flex items-center gap-3">
              <StatusBadge status={r.isActive === false ? "INACTIVE" : "ACTIVE"} />
              <Switch
                checked={r.isActive !== false}
                disabled={toggleActive.isPending}
                onChange={(checked) => toggleActive.mutate({ bannerId: idOf(r), isActive: checked })}
              />
            </div>
          )
        },
        { id: "date", header: "العرض", cell: (r) => `${formatDate(r.displayFrom)} - ${formatDate(r.displayUntil)}` },
      ]} normalize={(p) => Array.isArray(p) ? p as AnyRecord[] : []} />
    </div>
  );
}

export function ShippingPage() {
  const queryClient = useQueryClient();
  const [zoneName, setZoneName] = useState("");
  const [countryId, setCountryId] = useState("");
  const [methodName, setMethodName] = useState("");
  const [methodCode, setMethodCode] = useState("");
  const [etaMin, setEtaMin] = useState("1");
  const [etaMax, setEtaMax] = useState("3");
  const createZone = useMutation({
    mutationFn: () => adminApi("/api/admin/shipping/admin/zones", { method: "POST", body: { name: { ar: zoneName, en: zoneName }, scope: "COUNTRY", countryId: Number(countryId), isActive: true } }),
    onSuccess: async () => { toast.success("تم إنشاء منطقة الشحن"); setZoneName(""); setCountryId(""); await queryClient.invalidateQueries({ queryKey: ["/api/admin/shipping/zones"] }); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذر إنشاء المنطقة"),
  });
  const createMethod = useMutation({
    mutationFn: () => adminApi("/api/admin/shipping/admin/methods", { method: "POST", body: { name: { ar: methodName, en: methodName }, code: methodCode, etaMinDays: Number(etaMin), etaMaxDays: Number(etaMax), isActive: true } }),
    onSuccess: async () => { toast.success("تم إنشاء طريقة الشحن"); setMethodName(""); setMethodCode(""); await queryClient.invalidateQueries({ queryKey: ["/api/admin/shipping/methods"] }); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذر إنشاء الطريقة"),
  });
  return (
    <div className="space-y-6">
      <PageHeader title="الشحن" description="إدارة مناطق وطرق الشحن واختبار التهيئة." />
      <div className="flex flex-wrap gap-2">
        <Link href="/shipping/zones" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">مناطق الشحن</Link>
        <Link href="/shipping/methods" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">طرق الشحن</Link>
        <Link href="/shipping/vendor-rates" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">أسعار البائعين</Link>
        <Link href="/shipping/quote-tester" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">اختبار السعر</Link>
      </div>
      <SimpleCreateForm title="إضافة منطقة شحن" pending={createZone.isPending} onSubmit={() => createZone.mutate()} fields={[{ label: "الاسم", value: zoneName, onChange: setZoneName, required: true }, { label: "معرف الدولة الرقمي", value: countryId, onChange: setCountryId, required: true }]} />
      <ResourceList<AnyRecord> title="مناطق الشحن" description="" path="/api/admin/shipping/zones" normalize={(p) => Array.isArray(p) ? p as AnyRecord[] : []} columns={[
        { id: "name", header: "الاسم", cell: (r) => localizedText(r.name, text(r.code)) },
        { id: "scope", header: "النطاق", cell: (r) => text(r.scope) },
        { id: "status", header: "الحالة", cell: (r) => <StatusBadge status={r.isActive === false ? "INACTIVE" : "ACTIVE"} /> },
      ]} />
      <SimpleCreateForm title="إضافة طريقة شحن" pending={createMethod.isPending} onSubmit={() => createMethod.mutate()} fields={[{ label: "الاسم", value: methodName, onChange: setMethodName, required: true }, { label: "الكود", value: methodCode, onChange: setMethodCode, required: true }, { label: "أقل أيام", value: etaMin, onChange: setEtaMin, required: true }, { label: "أقصى أيام", value: etaMax, onChange: setEtaMax, required: true }]} />
      <ResourceList<AnyRecord> title="طرق الشحن" description="" path="/api/admin/shipping/methods" normalize={(p) => Array.isArray(p) ? p as AnyRecord[] : []} columns={[
        { id: "name", header: "الاسم", cell: (r) => localizedText(r.name, text(r.code)) },
        { id: "code", header: "الكود", cell: (r) => text(r.code) },
        { id: "eta", header: "المدة", cell: (r) => `${text(r.etaMinDays, "0")} - ${text(r.etaMaxDays, "0")} يوم` },
        { id: "status", header: "الحالة", cell: (r) => <StatusBadge status={r.isActive === false ? "INACTIVE" : "ACTIVE"} /> },
      ]} />
    </div>
  );
}

export function SettingsPage() {
  const queryClient = useQueryClient();
  const [key, setKey] = useState("");
  const [group, setGroup] = useState("MARKETPLACE");
  const [value, setValue] = useState("");
  const [type, setType] = useState("STRING");
  const save = useMutation({
    mutationFn: () => adminApi("/api/admin/admin/settings", { method: "PATCH", body: { settings: [{ key, group, value, type, isPublic: false }] } }),
    onSuccess: async () => { toast.success("تم تحديث الإعداد"); setKey(""); setValue(""); await queryClient.invalidateQueries({ queryKey: ["/api/admin/admin/settings"] }); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذر حفظ الإعداد"),
  });
  return (
    <div className="space-y-6">
      <PageHeader title="الإعدادات" description="تعديل إعدادات الأعمال بدون إعادة نشر الخادم." />
      <SimpleCreateForm title="إضافة / تحديث إعداد" pending={save.isPending} onSubmit={() => save.mutate()} fields={[{ label: "المفتاح", value: key, onChange: setKey, required: true }, { label: "المجموعة", value: group, onChange: setGroup, required: true }, { label: "القيمة", value, onChange: setValue, required: true }, { label: "النوع", value: type, onChange: setType, required: true }]} />
      <ResourceList<AnyRecord> title="كل الإعدادات" description="" path="/api/admin/admin/settings" normalize={(p) => Array.isArray(p) ? p as AnyRecord[] : []} columns={[
        { id: "key", header: "المفتاح", cell: (r) => <div><div className="font-medium">{text(r.key)}</div><div className="text-xs text-slate-500">{text(r.group)} · {text(r.type)}</div></div> },
        { id: "value", header: "القيمة", cell: (r) => <code className="text-xs">{text(r.value)}</code> },
        { id: "public", header: "عام؟", cell: (r) => r.isPublic ? "نعم" : "لا" },
        { id: "date", header: "آخر تحديث", cell: (r) => formatDate(r.updatedAt) },
      ]} />
    </div>
  );
}

export function BillingPage() {
  const runBilling = useMutation({
    mutationFn: () => adminApi("/api/admin/admin/vendor-billing/run", { method: "POST", body: {} }),
    onSuccess: () => toast.success("تم تشغيل مهمة الفوترة"),
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذر تشغيل الفوترة"),
  });
  const [paymentId, setPaymentId] = useState("");
  const [reviewStatus, setReviewStatus] = useState("SUCCEEDED");
  const [rejectionReason, setRejectionReason] = useState("");
  const reviewPayment = useMutation({
    mutationFn: () => adminApi(`/api/admin/admin/vendor-billing/payments/${paymentId}/review`, { method: "PATCH", body: { status: reviewStatus, rejectionReason: rejectionReason || undefined } }),
    onSuccess: () => { toast.success("تم اعتماد دفعة الفوترة"); setPaymentId(""); },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذر اعتماد الدفعة"),
  });
  return (
    <div className="space-y-6">
      <PageHeader title="فواتير البائعين" description="تشغيل الفوترة ومراجعة مدفوعات البائعين." />
      <div className="flex flex-wrap gap-2">
        <Link href="/billing/overview" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">نظرة عامة</Link>
        <Link href="/billing/vendors" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">حسابات البائعين</Link>
        <Link href="/billing/invoices" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">الفواتير</Link>
        <Link href="/billing/payments" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">دفعات الفوترة</Link>
        <Link href="/billing/jobs" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">المهام</Link>
      </div>
      <PageCard>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-sm font-semibold">تشغيل الفوترة</div>
            <p className="mt-1 text-sm text-slate-500">ينفذ توليد الفواتير وإنفاذ قواعد الفوترة من الخلفية.</p>
          </div>
          <button disabled={runBilling.isPending} onClick={() => runBilling.mutate()} className="rounded-md bg-teal-700 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">تشغيل مهمة الفوترة</button>
        </div>
      </PageCard>
      <SimpleCreateForm title="مراجعة دفعة فوترة" pending={reviewPayment.isPending} onSubmit={() => reviewPayment.mutate()} fields={[
        { label: "معرف دفعة الفوترة", value: paymentId, onChange: setPaymentId, required: true },
        { label: "الحالة", value: reviewStatus, onChange: setReviewStatus, required: true, placeholder: "SUCCEEDED / FAILED / REJECTED" },
        { label: "سبب الرفض", value: rejectionReason, onChange: setRejectionReason },
      ]} />
      <BackendGapCard
        title="قوائم الفواتير العامة غير متاحة بعد"
        description="الخلفية توفر ملخص وفواتير ومعاملات البائع عبر /v1/vendors/:vendorId/billing فقط، وتوفر للإدارة تشغيل الفوترة ومراجعة الدفعات. تحتاج اللوحة إلى endpoint إداري عام لقائمة الفواتير والدفعات حتى تعرض صفحة مالية كاملة."
      />
    </div>
  );
}

export function AuditLogsPage() {
  return (
    <ResourceList<AnyRecord>
      title="سجل التدقيق"
      description="تتبع إجراءات الإدارة الحساسة."
      path="/api/admin/admin/audit-logs"
      columns={[
        { id: "action", header: "الإجراء", cell: (r) => <Link href={`/audit-logs/${idOf(r)}`} className="font-medium text-teal-800 hover:underline">{text(r.action)}</Link> },
        { id: "actor", header: "المسؤول", cell: (r) => text((r.actor as AnyRecord | undefined)?.email, "System") },
        { id: "target", header: "الهدف", cell: (r) => `${text(r.targetType)} #${text(r.targetId)}` },
        { id: "date", header: "التاريخ", cell: (r) => formatDate(r.createdAt) },
      ]}
    />
  );
}

export function OpsPage() {
  return (
    <div className="space-y-6">
      <PageHeader title="تشغيل النظام" description="صحة النظام، الطوابير، والعمليات الخلفية." />
      <div className="flex flex-wrap gap-2">
        <Link href="/ops/health" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">الصحة والمقاييس</Link>
        <Link href="/ops/queues" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">الطوابير</Link>
        <Link href="/ops/webhooks" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">Webhooks</Link>
        <Link href="/ops/jobs" className="rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-100">المهام</Link>
      </div>
      <ResourceList<AnyRecord> title="حالة الطوابير" description="" path="/api/admin/admin/ops/queues" normalize={(p) => Object.entries((p ?? {}) as AnyRecord).map(([name, value]) => ({ name, value }))} columns={[
        { id: "name", header: "الطابور", cell: (r) => text(r.name) },
        { id: "value", header: "القيمة", cell: (r) => <pre className="max-w-xl overflow-auto text-xs">{JSON.stringify(r.value, null, 2)}</pre> },
      ]} />
      <BackendGapCard
        title="فحوصات الصحة والمقاييس خارج proxy الإدارة"
        description="فحوصات /health و /metrics خارج بادئة /v1 في الخلفية. يمكن إضافة route handler منفصل داخل Next proxy لاحقا لعرضها مع حماية الجلسة الإدارية."
      />
    </div>
  );
}
