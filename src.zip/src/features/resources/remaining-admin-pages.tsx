"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { CursorDataTable } from "@/components/data-table/cursor-data-table";
import { PageHeader } from "@/components/layout/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/state/async-states";
import { StatusBadge } from "@/components/status/status-badge";
import { adminApi } from "@/lib/api/admin-client";
import { ImageUploadInput } from "@/components/image-upload-input";
import { formatDate, formatMoney, localizedText, formatName, roleLabel } from "@/lib/formatters";
import { ClickableImageWithFileFallback } from "@/components/clickable-image-fallback";

type AnyRecord = Record<string, unknown>;

function text(value: unknown, fallback = "-") {
  if (value === null || value === undefined || value === "") return fallback;
  if (typeof value === "object") return localizedText(value, fallback, "ar");
  return String(value);
}

function idOf(row: AnyRecord) {
  return String(row.publicId ?? row.id ?? row.key ?? Math.random());
}

function toArray(payload: unknown) {
  if (Array.isArray(payload)) return payload as AnyRecord[];
  if (payload && typeof payload === "object") {
    const record = payload as { data?: unknown };
    if (Array.isArray(record.data)) return record.data as AnyRecord[];
  }
  return [];
}

function PageCard({ children }: { children: React.ReactNode }) {
  return <div className="rounded-md border border-slate-200 bg-white p-4">{children}</div>;
}

function GapCard({ title, description }: { title: string; description: string }) {
  return (
    <div className="rounded-md border border-amber-200 bg-amber-50 p-4 text-sm">
      <div className="font-semibold text-amber-900">{title}</div>
      <p className="mt-2 leading-6 text-amber-800">{description}</p>
    </div>
  );
}

function TextInput({
  label,
  value,
  onChange,
  required,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
  placeholder?: string;
}) {
  return (
    <label className="block text-sm font-medium text-slate-700">
      {label}
      <input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        required={required}
        placeholder={placeholder}
        className="mt-1 h-10 w-full rounded-md border border-slate-200 px-3 text-sm outline-none"
      />
    </label>
  );
}

function DetailGrid({ rows }: { rows: Array<{ label: string; value: React.ReactNode }> }) {
  return (
    <PageCard>
      <dl className="grid gap-4 md:grid-cols-3">
        {rows.map((row) => (
          <div key={row.label}>
            <dt className="text-xs font-semibold text-slate-500">{row.label}</dt>
            <dd className="mt-1 text-sm text-slate-900">{row.value}</dd>
          </div>
        ))}
      </dl>
    </PageCard>
  );
}

function JsonBlock({ value }: { value: unknown }) {
  return (
    <pre className="max-h-96 overflow-auto rounded-md bg-slate-950 p-3 text-xs leading-6 text-slate-50">
      {JSON.stringify(value, null, 2)}
    </pre>
  );
}

function userRoleId(role: unknown) {
  if (!role || typeof role !== "object") return undefined;
  const record = role as Record<string, unknown>;
  if (typeof record.roleId === "number") return record.roleId;
  if (record.role && typeof record.role === "object") {
    const nested = record.role as Record<string, unknown>;
    if (typeof nested.id === "number") return nested.id;
  }
  return undefined;
}

export function UserDetailPage({ userId }: { userId: string }) {
  const queryClient = useQueryClient();
  const [roleId, setRoleId] = useState("");

  const userQuery = useQuery({
    queryKey: ["users", userId],
    queryFn: () => adminApi<AnyRecord>(`/api/admin/admin/users/${userId}`),
  });

  const ordersQuery = useQuery({
    queryKey: ["users", userId, "orders"],
    queryFn: () => adminApi<unknown>(`/api/admin/admin/users/${userId}/orders?limit=10`),
  });

  const verificationsQuery = useQuery({
    queryKey: ["users", userId, "verifications"],
    queryFn: () => adminApi<AnyRecord[]>(`/api/admin/admin/users/${userId}/verifications`),
  });

  const rolesQuery = useQuery({
    queryKey: ["roles"],
    queryFn: () => adminApi<AnyRecord[]>("/api/admin/roles"),
  });

  const updateStatus = useMutation({
    mutationFn: (status: "ACTIVE" | "SUSPENDED") =>
      adminApi(`/api/admin/admin/users/${userId}/status`, {
        method: "PATCH",
        body: { status },
      }),
    onSuccess: async () => {
      toast.success("تم تحديث حالة المستخدم بنجاح");
      await queryClient.invalidateQueries({ queryKey: ["users", userId] });
      await queryClient.invalidateQueries({ queryKey: ["users"] });
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "تعذر تحديث حالة المستخدم");
    },
  });

  const assignRole = useMutation({
    mutationFn: (targetUserId: number) =>
      adminApi("/api/admin/roles/assign", {
        method: "POST",
        body: { userId: targetUserId, roleId: Number(roleId) },
      }),
    onSuccess: async () => {
      toast.success("تم تعيين الدور بنجاح");
      setRoleId("");
      await queryClient.invalidateQueries({ queryKey: ["users", userId] });
      await queryClient.invalidateQueries({ queryKey: ["users"] });
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "تعذر تعيين الدور");
    },
  });

  const revokeRole = useMutation({
    mutationFn: ({ targetUserId, nextRoleId }: { targetUserId: number; nextRoleId: number }) =>
      adminApi(`/api/admin/roles/users/${targetUserId}/roles/${nextRoleId}`, {
        method: "DELETE",
      }),
    onSuccess: async () => {
      toast.success("تم حذف الدور بنجاح");
      await queryClient.invalidateQueries({ queryKey: ["users", userId] });
      await queryClient.invalidateQueries({ queryKey: ["users"] });
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "تعذر حذف الدور");
    },
  });

  const user = userQuery.data;
  const ordersPayload = ordersQuery.data;
  const orders = toArray(ordersPayload);
  const verifications = verificationsQuery.data ?? [];
  const roles = rolesQuery.data ?? [];

  if (userQuery.isLoading) return <LoadingState label="جار تحميل بيانات المستخدم" />;
  if (userQuery.isError) return <ErrorState message={userQuery.error.message} />;
  if (!user) return <EmptyState title="المستخدم غير موجود" description="لم نتمكن من العثور على هذا المستخدم." />;

  const nextStatus = user.status === "SUSPENDED" ? "ACTIVE" : "SUSPENDED";

  return (
    <div className="space-y-6">
      <PageHeader
        title={`ملف المستخدم: ${formatName(user)}`}
        description="عرض وتحديث بيانات الحساب والأدوار وسجل الطلبات والتحقق."
        actions={
          <Link href="/users" className="rounded-md border border-slate-200 px-3 py-2 text-sm font-medium hover:bg-slate-100">
            كل المستخدمين
          </Link>
        }
      />

      <DetailGrid
        rows={[
          { label: "المعرف العام", value: text(user.publicId) },
          { label: "المعرف الداخلي", value: text(user.id) },
          { label: "البريد الإلكتروني", value: text(user.email) },
          { label: "رقم الهاتف", value: text(user.phone) },
          { label: "الحالة", value: <StatusBadge status={text(user.status, "UNKNOWN")} /> },
          { label: "اللغة المفضلة", value: text(user.locale) },
          { label: "تاريخ التسجيل", value: formatDate(user.createdAt) },
          { label: "آخر تسجيل دخول", value: formatDate(user.lastLoginAt) },
        ]}
      />

      <PageCard>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="text-sm font-semibold">إدارة الحساب</div>
            <p className="mt-1 text-xs text-slate-500">إيقاف أو إعادة تنشيط حساب المستخدم في النظام.</p>
          </div>
          <div>
            <button
              type="button"
              disabled={updateStatus.isPending}
              onClick={() => {
                const ok = window.confirm(
                  `${nextStatus === "SUSPENDED" ? "إيقاف" : "إعادة تنشيط"} ${user.email ?? user.publicId}؟`
                );
                if (ok) updateStatus.mutate(nextStatus);
              }}
              className="rounded-md border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50"
            >
              {nextStatus === "SUSPENDED" ? "إيقاف الحساب" : "تنشيط الحساب"}
            </button>
          </div>
        </div>
      </PageCard>

      <PageCard>
        <div className="mb-4">
          <div className="text-sm font-semibold">أدوار المستخدم الصالحة</div>
          <p className="mt-1 text-xs text-slate-500">الأدوار الممنوحة لهذا المستخدم على مستوى النظام.</p>
        </div>

        <div className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {((user.roles as AnyRecord[]) ?? []).map((role: AnyRecord, index: number) => {
              const label = roleLabel(role);
              const id = userRoleId(role);
              return (
                <span
                  key={`${label}-${index}`}
                  className="inline-flex items-center gap-1.5 rounded-md bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-700"
                >
                  {label}
                  {id && label !== "ADMIN" ? (
                    <button
                      type="button"
                      disabled={revokeRole.isPending}
                      onClick={() => revokeRole.mutate({ targetUserId: Number(user.id), nextRoleId: id })}
                      className="text-slate-400 hover:text-red-600 font-bold"
                      title="حذف الدور"
                    >
                      ×
                    </button>
                  ) : null}
                </span>
              );
            })}
            {((user.roles as AnyRecord[]) ?? []).length === 0 ? (
              <span className="text-xs text-slate-500">لا توجد أدوار معينة حالياً (مستخدم عادي).</span>
            ) : null}
          </div>

          <div className="flex items-center gap-2 max-w-sm">
            <select
              value={roleId}
              onChange={(event) => setRoleId(event.target.value)}
              className="h-9 w-full rounded-md border border-slate-200 bg-white px-3 text-xs outline-none"
            >
              <option value="">اختر دوراً لتعيينه...</option>
              {roles.map((role) => (
                <option key={String(role.id)} value={String(role.id)}>
                  {String(role.name ?? "")}
                </option>
              ))}
            </select>
            <button
              type="button"
              disabled={!roleId || assignRole.isPending}
              onClick={() => assignRole.mutate(Number(user.id))}
              className="h-9 rounded-md bg-teal-700 px-4 text-xs font-medium text-white hover:bg-teal-800 disabled:opacity-50"
            >
              إسناد
            </button>
          </div>
        </div>
      </PageCard>

      <PageCard>
        <div className="mb-3">
          <div className="text-sm font-semibold">وثائق التحقق والـ KYC</div>
          <p className="mt-1 text-xs text-slate-500">الطلبات والمستندات المقدمة للتحقق من الهوية.</p>
        </div>
        {verificationsQuery.isLoading ? (
          <LoadingState label="جار تحميل الوثائق" />
        ) : verificationsQuery.isError ? (
          <ErrorState message={verificationsQuery.error.message} />
        ) : verifications.length === 0 ? (
          <p className="text-xs text-slate-500">لم يقدم هذا المستخدم أي وثائق تحقق بعد.</p>
        ) : (
          <CursorDataTable
            data={verifications}
            getRowKey={(row) => String(row.id)}
            columns={[
              {
                id: "document",
                header: "الوثيقة",
                cell: (row) => (
                  <div>
                    <div className="font-medium">{text(row.documentType)}</div>
                    <div className="text-xs text-slate-500">{text(row.documentNumber)}</div>
                  </div>
                ),
              },
              {
                id: "status",
                header: "الحالة",
                cell: (row) => <StatusBadge status={String(row.status ?? "")} />,
              },
              {
                id: "dates",
                header: "التواريخ",
                cell: (row) => (
                  <div className="text-xs text-slate-600">
                    <div>تم الإرسال {formatDate(row.createdAt)}</div>
                    <div>تنتهي {formatDate(row.expiresAt)}</div>
                  </div>
                ),
              },
              {
                id: "files",
                header: "الملفات",
                cell: (row) => (
                  <div className="flex flex-col gap-2 py-1">
                    {row.fileUrl ? (
                      <div className="flex items-center gap-2">
                        <div className="h-10 w-10 shrink-0 overflow-hidden rounded border border-slate-200 bg-slate-100 flex items-center justify-center">
                          <ClickableImageWithFileFallback src={String(row.fileUrl)} alt="الملف الرئيسي" className="h-full w-full object-cover" fallbackLabel="الملف الرئيسي" />
                        </div>
                        <span className="text-xs text-slate-600">الملف الرئيسي</span>
                      </div>
                    ) : null}
                    {row.frontFileUrl ? (
                      <div className="flex items-center gap-2">
                        <div className="h-10 w-10 shrink-0 overflow-hidden rounded border border-slate-200 bg-slate-100 flex items-center justify-center">
                          <ClickableImageWithFileFallback src={String(row.frontFileUrl)} alt="الوجه الأمامي" className="h-full w-full object-cover" fallbackLabel="الوجه الأمامي" />
                        </div>
                        <span className="text-xs text-slate-600">الوجه الأمامي</span>
                      </div>
                    ) : null}
                    {row.backFileUrl ? (
                      <div className="flex items-center gap-2">
                        <div className="h-10 w-10 shrink-0 overflow-hidden rounded border border-slate-200 bg-slate-100 flex items-center justify-center">
                          <ClickableImageWithFileFallback src={String(row.backFileUrl)} alt="الوجه الخلفي" className="h-full w-full object-cover" fallbackLabel="الوجه الخلفي" />
                        </div>
                        <span className="text-xs text-slate-600">الوجه الخلفي</span>
                      </div>
                    ) : null}
                  </div>
                ),
              },
            ]}
          />
        )}
      </PageCard>

      <PageCard>
        <div className="mb-3">
          <div className="text-sm font-semibold">آخر الطلبات</div>
          <p className="mt-1 text-xs text-slate-500">الطلبات التي تم إنشاؤها بواسطة هذا المستخدم.</p>
        </div>
        {ordersQuery.isLoading ? (
          <LoadingState label="جار تحميل الطلبات" />
        ) : ordersQuery.isError ? (
          <ErrorState message={ordersQuery.error.message} />
        ) : orders.length === 0 ? (
          <p className="text-xs text-slate-500">لا توجد طلبات سابقة لهذا المستخدم.</p>
        ) : (
          <CursorDataTable
            data={orders}
            getRowKey={(row) => idOf(row)}
            columns={[
              {
                id: "order",
                header: "الطلب",
                cell: (row) => (
                  <Link className="font-medium text-teal-800 hover:underline" href={`/orders/${idOf(row)}`}>
                    {text(row.publicId)}
                  </Link>
                ),
              },
              { id: "status", header: "الحالة", cell: (row) => <StatusBadge status={text(row.status, "UNKNOWN")} /> },
              { id: "payment", header: "الدفع", cell: (row) => <StatusBadge status={text(row.paymentStatus, "UNKNOWN")} /> },
              { id: "total", header: "الإجمالي", cell: (row) => formatMoney(row.totalCents, text(row.currency, "EGP")) },
              { id: "date", header: "التاريخ", cell: (row) => formatDate(row.placedAt ?? row.createdAt) },
            ]}
          />
        )}
      </PageCard>
    </div>
  );
}

export function BulkOrderDetailPage({ bulkOrderId }: { bulkOrderId: string }) {
  const bulkOrder = useQuery({
    queryKey: ["/api/admin/bulk/orders", bulkOrderId],
    queryFn: () => adminApi<AnyRecord>(`/api/admin/bulk/orders/${bulkOrderId}`),
  });
  const row = bulkOrder.data;
  const items = Array.isArray(row?.items) ? row.items as AnyRecord[] : [];

  return (
    <div className="space-y-6">
      <PageHeader
        title={`تفاصيل طلب الجملة ${bulkOrderId}`}
        description="تفتيش طلبات الجملة المتاحة من endpoint المشتري الحالي، مع توضيح فجوات الإدارة."
        actions={<Link href="/bulk-orders" className="rounded-md border border-slate-200 px-3 py-2 text-sm font-medium hover:bg-slate-100">طلبات الجملة</Link>}
      />
      {bulkOrder.isLoading ? (
        <LoadingState label="جار تحميل طلب الجملة" />
      ) : bulkOrder.isError ? (
        <ErrorState message={bulkOrder.error.message} />
      ) : row ? (
        <>
          <DetailGrid rows={[
            { label: "المعرف", value: text(row.publicId) },
            { label: "الحالة", value: <StatusBadge status={text(row.status, "UNKNOWN")} /> },
            { label: "الدفع", value: <StatusBadge status={text(row.paymentStatus, "UNKNOWN")} /> },
            { label: "الإجمالي", value: formatMoney(row.totalCents, text(row.currency, "EGP")) },
            { label: "تاريخ الإنشاء", value: formatDate(row.createdAt) },
            { label: "آخر تحديث", value: formatDate(row.updatedAt) },
          ]} />
          <PageCard>
            <div className="mb-3 text-sm font-semibold">العناصر</div>
            <CursorDataTable
              data={items}
              getRowKey={(item) => idOf(item)}
              columns={[
                { id: "product", header: "المنتج", cell: (item) => localizedText((item.product as AnyRecord | undefined)?.title, text(item.productId), "ar") },
                { id: "qty", header: "الكمية", cell: (item) => text(item.quantity, "0") },
                { id: "price", header: "السعر", cell: (item) => formatMoney(item.unitPriceCents, text(row.currency, "EGP")) },
                { id: "total", header: "الإجمالي", cell: (item) => formatMoney(item.totalCents, text(row.currency, "EGP")) },
              ]}
            />
          </PageCard>
          <GapCard
            title="إجراءات الإدارة لطلبات الجملة تحتاج endpoints إدارية"
            description="العرض الحالي يعتمد على /v1/bulk/orders/:orderId. تحديث الحالة، الوفاء، والملاحظات من الإدارة تحتاج /v1/admin/bulk-orders/:bulkOrderId وما يتبعها."
          />
        </>
      ) : null}
    </div>
  );
}

export function RefundDetailPage({ refundId }: { refundId: string }) {
  return (
    <div className="space-y-4">
      <PageHeader title={`تفاصيل الاسترداد ${refundId}`} description="تفاصيل الاستردادات ستظهر هنا عند توفر endpoint إداري." />
      <GapCard
        title="لا يوجد endpoint تفاصيل استرداد"
        description="الاستردادات تظهر حاليا ضمن تفاصيل الدفع فقط. تحتاج الخلفية إلى GET /v1/admin/refunds/:refundId لعرض صفحة مستقلة."
      />
    </div>
  );
}

export function CatalogBrandsPage() {
  const queryClient = useQueryClient();
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const brands = useQuery({
    queryKey: ["/api/admin/brands"],
    queryFn: () => adminApi<unknown>("/api/admin/brands?limit=50"),
  });
  const createBrand = useMutation({
    mutationFn: () => adminApi("/api/admin/brands", { method: "POST", body: { name: { ar: name, en: name }, slug, isActive: true } }),
    onSuccess: async () => {
      toast.success("تم إنشاء العلامة التجارية");
      setName("");
      setSlug("");
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/brands"] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر إنشاء العلامة"),
  });

  return (
    <div className="space-y-6">
      <PageHeader title="العلامات التجارية" description="إنشاء وتحديث العلامات التجارية في الكتالوج." actions={<Link href="/catalog" className="rounded-md border border-slate-200 px-3 py-2 text-sm hover:bg-slate-100">الكتالوج</Link>} />
      <PageCard>
        <form onSubmit={(event) => { event.preventDefault(); createBrand.mutate(); }} className="grid gap-3 md:grid-cols-[1fr_1fr_auto] md:items-end">
          <TextInput label="الاسم" value={name} onChange={setName} required />
          <TextInput label="Slug" value={slug} onChange={setSlug} required />
          <button disabled={createBrand.isPending} className="h-10 rounded-md bg-teal-700 px-4 text-sm font-semibold text-white disabled:opacity-50">حفظ</button>
        </form>
      </PageCard>
      {brands.isLoading ? <LoadingState /> : brands.isError ? <ErrorState message={brands.error.message} /> : (
        <CursorDataTable
          data={toArray(brands.data)}
          getRowKey={(brand) => idOf(brand)}
          columns={[
            { id: "name", header: "الاسم", cell: (brand) => <Link href={`/catalog/brands/${idOf(brand)}`} className="font-medium text-teal-800 hover:underline">{localizedText(brand.name, text(brand.slug), "ar")}</Link> },
            { id: "slug", header: "Slug", cell: (brand) => text(brand.slug) },
            { id: "status", header: "الحالة", cell: (brand) => <StatusBadge status={brand.isActive === false ? "INACTIVE" : "ACTIVE"} /> },
            { id: "date", header: "التاريخ", cell: (brand) => formatDate(brand.createdAt) },
          ]}
        />
      )}
    </div>
  );
}

export function BrandDetailPage({ brandId }: { brandId: string }) {
  return <SimpleCatalogDetail entityId={brandId} kind="brand" title="العلامة التجارية" basePath="/api/admin/brands" backHref="/catalog/brands" />;
}

export function CatalogStoreCategoriesPage() {
  const queryClient = useQueryClient();
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const list = useQuery({
    queryKey: ["/api/admin/store-categories"],
    queryFn: () => adminApi<AnyRecord[]>("/api/admin/store-categories"),
  });
  const create = useMutation({
    mutationFn: () => adminApi("/api/admin/store-categories", { method: "POST", body: { name: { ar: name, en: name }, slug, isActive: true } }),
    onSuccess: async () => {
      toast.success("تم إنشاء تصنيف المتجر");
      setName("");
      setSlug("");
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/store-categories"] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر إنشاء تصنيف المتجر"),
  });

  return (
    <div className="space-y-6">
      <PageHeader title="تصنيفات المتاجر" description="إدارة تصنيفات واجهات البائعين." actions={<Link href="/catalog" className="rounded-md border border-slate-200 px-3 py-2 text-sm hover:bg-slate-100">الكتالوج</Link>} />
      <PageCard>
        <form onSubmit={(event) => { event.preventDefault(); create.mutate(); }} className="grid gap-3 md:grid-cols-[1fr_1fr_auto] md:items-end">
          <TextInput label="الاسم" value={name} onChange={setName} required />
          <TextInput label="Slug" value={slug} onChange={setSlug} required />
          <button disabled={create.isPending} className="h-10 rounded-md bg-teal-700 px-4 text-sm font-semibold text-white disabled:opacity-50">حفظ</button>
        </form>
      </PageCard>
      {list.isLoading ? <LoadingState /> : list.isError ? <ErrorState message={list.error.message} /> : (
        <CursorDataTable
          data={list.data ?? []}
          getRowKey={(item) => idOf(item)}
          columns={[
            { id: "name", header: "الاسم", cell: (item) => <Link href={`/catalog/store-categories/${idOf(item)}`} className="font-medium text-teal-800 hover:underline">{localizedText(item.name, text(item.slug), "ar")}</Link> },
            { id: "slug", header: "Slug", cell: (item) => text(item.slug) },
            { id: "status", header: "الحالة", cell: (item) => <StatusBadge status={item.isActive === false ? "INACTIVE" : "ACTIVE"} /> },
            { id: "date", header: "التاريخ", cell: (item) => formatDate(item.createdAt) },
          ]}
        />
      )}
    </div>
  );
}

export function StoreCategoryDetailPage({ storeCategoryId }: { storeCategoryId: string }) {
  return <SimpleCatalogDetail entityId={storeCategoryId} kind="storeCategory" title="تصنيف المتجر" basePath="/api/admin/store-categories" backHref="/catalog/store-categories" />;
}

function SimpleCatalogDetail({
  entityId,
  title,
  basePath,
  backHref,
}: {
  entityId: string;
  kind: "brand" | "storeCategory";
  title: string;
  basePath: string;
  backHref: string;
}) {
  const queryClient = useQueryClient();
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [isActive, setIsActive] = useState("true");
  const detail = useQuery({
    queryKey: [basePath, entityId],
    queryFn: () => adminApi<AnyRecord>(`${basePath}/${entityId}`),
  });
  useEffect(() => {
    if (!detail.data) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setName(localizedText(detail.data.name, "", "ar"));
    setSlug(text(detail.data.slug, ""));
    setIsActive(detail.data.isActive === false ? "false" : "true");
  }, [detail.data]);
  const update = useMutation({
    mutationFn: () => adminApi(`${basePath}/${entityId}`, { method: "PATCH", body: { name: name ? { ar: name, en: name } : undefined, slug: slug || undefined, isActive: isActive === "true" } }),
    onSuccess: async () => {
      toast.success("تم الحفظ");
      await queryClient.invalidateQueries({ queryKey: [basePath, entityId] });
      await queryClient.invalidateQueries({ queryKey: [basePath] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر الحفظ"),
  });
  const remove = useMutation({
    mutationFn: () => adminApi(`${basePath}/${entityId}`, { method: "DELETE" }),
    onSuccess: async () => {
      toast.success("تم الحذف");
      await queryClient.invalidateQueries({ queryKey: [basePath] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر الحذف"),
  });

  return (
    <div className="space-y-6">
      <PageHeader title={`${title} ${entityId}`} description="تحديث بيانات الكتالوج وحالة الظهور." actions={<Link href={backHref} className="rounded-md border border-slate-200 px-3 py-2 text-sm hover:bg-slate-100">رجوع</Link>} />
      {detail.isLoading ? <LoadingState /> : detail.isError ? <ErrorState message={detail.error.message} /> : (
        <>
          <DetailGrid rows={[
            { label: "المعرف", value: text(detail.data?.publicId) },
            { label: "Slug", value: text(detail.data?.slug) },
            { label: "الحالة", value: <StatusBadge status={detail.data?.isActive === false ? "INACTIVE" : "ACTIVE"} /> },
            { label: "تاريخ الإنشاء", value: formatDate(detail.data?.createdAt) },
          ]} />
          <PageCard>
            <form onSubmit={(event) => { event.preventDefault(); update.mutate(); }} className="grid gap-3 md:grid-cols-3">
              <TextInput label="الاسم" value={name} onChange={setName} required />
              <TextInput label="Slug" value={slug} onChange={setSlug} required />
              <TextInput label="نشط؟ true/false" value={isActive} onChange={setIsActive} required />
              <div className="flex gap-2 md:col-span-3">
                <button disabled={update.isPending} className="rounded-md bg-teal-700 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">حفظ</button>
                <button type="button" disabled={remove.isPending} onClick={() => { if (window.confirm("حذف العنصر؟")) remove.mutate(); }} className="rounded-md border border-red-200 px-4 py-2 text-sm font-semibold text-red-700 disabled:opacity-50">حذف</button>
              </div>
            </form>
          </PageCard>
        </>
      )}
    </div>
  );
}

export function CatalogAttributesIndexPage() {
  return (
    <div className="space-y-4">
      <PageHeader title="خصائص التصنيفات" description="تدار الخصائص من صفحة كل تصنيف حتى تبقى مربوطة بسياقها الصحيح." />
      <EmptyState title="اختر تصنيفا من الكتالوج" description="افتح /catalog ثم اضغط على أي تصنيف لإضافة خصائصه أو تعديلها أو حذفها." />
      <Link href="/catalog" className="inline-flex rounded-md bg-teal-700 px-4 py-2 text-sm font-semibold text-white">فتح الكتالوج</Link>
    </div>
  );
}

export function PromotionCreatePage() {
  return <PromotionEditorPage mode="create" />;
}

export function PromotionDetailPage({ promotionId }: { promotionId: string }) {
  return <PromotionEditorPage mode="edit" promotionId={promotionId} />;
}

function PromotionEditorPage({ mode, promotionId }: { mode: "create" | "edit"; promotionId?: string }) {
  const queryClient = useQueryClient();
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [status, setStatus] = useState("ACTIVE");
  const [valueBps, setValueBps] = useState("1000");
  const [validUntil, setValidUntil] = useState("");
  const detail = useQuery({
    queryKey: ["/api/admin/admin/promotions", promotionId],
    queryFn: () => adminApi<AnyRecord>(`/api/admin/admin/promotions/${promotionId}`),
    enabled: mode === "edit" && Boolean(promotionId),
  });
  useEffect(() => {
    if (!detail.data) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setCode(text(detail.data.code, ""));
    setName(localizedText(detail.data.name, "", "ar"));
    setStatus(text(detail.data.status, "ACTIVE"));
    setValueBps(text(detail.data.valueBps, "1000"));
    setValidUntil(detail.data.validUntil ? new Date(String(detail.data.validUntil)).toISOString().slice(0, 16) : "");
  }, [detail.data]);
  const save = useMutation({
    mutationFn: () => {
      const body = {
        code: code || undefined,
        name: { ar: name, en: name },
        discountType: "PERCENTAGE",
        scope: "PLATFORM",
        valueBps: Number(valueBps),
        validFrom: detail.data?.validFrom ? String(detail.data.validFrom) : new Date().toISOString(),
        validUntil: validUntil ? new Date(validUntil).toISOString() : undefined,
        status,
      };
      return adminApi(`/api/admin/admin/promotions${mode === "edit" ? `/${promotionId}` : ""}`, { method: mode === "edit" ? "PATCH" : "POST", body });
    },
    onSuccess: async () => {
      toast.success("تم حفظ العرض");
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/admin/promotions"] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر حفظ العرض"),
  });
  const remove = useMutation({
    mutationFn: () => adminApi(`/api/admin/admin/promotions/${promotionId}`, { method: "DELETE" }),
    onSuccess: async () => {
      toast.success("تم حذف العرض");
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/admin/promotions"] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر حذف العرض"),
  });

  return (
    <div className="space-y-6">
      <PageHeader title={mode === "create" ? "إنشاء عرض" : `تفاصيل العرض ${promotionId}`} description="إنشاء وتعديل كوبونات المنصة." actions={<Link href="/promotions" className="rounded-md border border-slate-200 px-3 py-2 text-sm hover:bg-slate-100">العروض</Link>} />
      {detail.isLoading ? <LoadingState /> : detail.isError ? <ErrorState message={detail.error.message} /> : (
        <PageCard>
          <form onSubmit={(event) => { event.preventDefault(); save.mutate(); }} className="grid gap-3 md:grid-cols-3">
            <TextInput label="الكود" value={code} onChange={setCode} />
            <TextInput label="الاسم" value={name} onChange={setName} required />
            <TextInput label="الحالة" value={status} onChange={setStatus} required placeholder="ACTIVE / DRAFT / CANCELLED" />
            <TextInput label="النسبة BPS" value={valueBps} onChange={setValueBps} required />
            <TextInput label="ينتهي في" value={validUntil} onChange={setValidUntil} placeholder="YYYY-MM-DDTHH:mm" />
            <div className="flex items-end gap-2">
              <button disabled={save.isPending} className="h-10 rounded-md bg-teal-700 px-4 text-sm font-semibold text-white disabled:opacity-50">حفظ</button>
              {mode === "edit" ? <button type="button" disabled={remove.isPending} onClick={() => { if (window.confirm("حذف العرض؟")) remove.mutate(); }} className="h-10 rounded-md border border-red-200 px-4 text-sm font-semibold text-red-700 disabled:opacity-50">حذف</button> : null}
            </div>
          </form>
        </PageCard>
      )}
    </div>
  );
}

export function BannerCreatePage() {
  return <BannerEditorPage mode="create" />;
}

export function BannerDetailPage({ bannerId }: { bannerId: string }) {
  return <BannerEditorPage mode="edit" bannerId={bannerId} />;
}

function BannerEditorPage({ mode, bannerId }: { mode: "create" | "edit"; bannerId?: string }) {
  const queryClient = useQueryClient();
  const [imageFileId, setImageFileId] = useState("");
  const [title, setTitle] = useState("");
  const [position, setPosition] = useState("HOME_HERO");
  const [linkTarget, setLinkTarget] = useState("");
  const [isActive, setIsActive] = useState("true");
  const detail = useQuery({
    queryKey: ["/api/admin/admin/banners", bannerId],
    queryFn: () => adminApi<AnyRecord>(`/api/admin/admin/banners/${bannerId}`),
    enabled: mode === "edit" && Boolean(bannerId),
  });
  useEffect(() => {
    if (!detail.data) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setImageFileId(text(detail.data.imageFileId, ""));
    setTitle(localizedText(detail.data.title, "", "ar"));
    setPosition(text(detail.data.position, "HOME_HERO"));
    setLinkTarget(text(detail.data.linkTarget, ""));
    setIsActive(detail.data.isActive === false ? "false" : "true");
  }, [detail.data]);
  const save = useMutation({
    mutationFn: () => adminApi(`/api/admin/admin/banners${mode === "edit" ? `/${bannerId}` : ""}`, {
      method: mode === "edit" ? "PATCH" : "POST",
      body: { imageFileId, title: { ar: title, en: title }, position, linkTarget: linkTarget || undefined, isActive: isActive === "true" },
    }),
    onSuccess: async () => {
      toast.success("تم حفظ البانر");
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/admin/banners"] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر حفظ البانر"),
  });
  const remove = useMutation({
    mutationFn: () => adminApi(`/api/admin/admin/banners/${bannerId}`, { method: "DELETE" }),
    onSuccess: async () => {
      toast.success("تم حذف البانر");
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/admin/banners"] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر حذف البانر"),
  });

  return (
    <div className="space-y-6">
      <PageHeader title={mode === "create" ? "إنشاء بانر" : `تفاصيل البانر ${bannerId}`} description="إدارة بانرات الحملات والصفحة الرئيسية." actions={<Link href="/banners" className="rounded-md border border-slate-200 px-3 py-2 text-sm hover:bg-slate-100">البانرات</Link>} />
      {detail.isLoading ? <LoadingState /> : detail.isError ? <ErrorState message={detail.error.message} /> : (
        <PageCard>
          <form onSubmit={(event) => { event.preventDefault(); save.mutate(); }} className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <TextInput label="العنوان" value={title} onChange={setTitle} required />
              <label className="block text-sm font-medium text-slate-700">
                الموضع
                <select value={position} onChange={(e) => setPosition(e.target.value)} className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm outline-none">
                  <option value="HOME_HERO">HOME_HERO</option>
                  <option value="HOME_STRIP">HOME_STRIP</option>
                  <option value="CATEGORY_HEADER">CATEGORY_HEADER</option>
                  <option value="CATEGORIES_FEATURED">CATEGORIES_FEATURED</option>
                </select>
              </label>
              <TextInput label="الرابط" value={linkTarget} onChange={setLinkTarget} />
              <label className="block text-sm font-medium text-slate-700">
                نشط؟
                <select value={isActive} onChange={(e) => setIsActive(e.target.value)} className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm outline-none">
                  <option value="true">نشط (Active)</option>
                  <option value="false">غير نشط (Inactive)</option>
                </select>
              </label>
            </div>
            
            <ImageUploadInput label="صورة البانر" value={imageFileId} onChange={setImageFileId} purpose="BANNER_IMAGE" required />
            
            <div className="flex gap-2">
              <button disabled={save.isPending || !imageFileId} className="h-10 rounded-md bg-teal-700 px-4 text-sm font-semibold text-white disabled:opacity-50 cursor-pointer">حفظ</button>
              {mode === "edit" ? <button type="button" disabled={remove.isPending} onClick={() => { if (window.confirm("حذف البانر؟")) remove.mutate(); }} className="h-10 rounded-md border border-red-200 px-4 text-sm font-semibold text-red-700 disabled:opacity-50 cursor-pointer">حذف</button> : null}
            </div>
          </form>
        </PageCard>
      )}
    </div>
  );
}

export function ShippingZonesPage() {
  return <ShippingEntityPage type="zones" title="مناطق الشحن" />;
}

export function ShippingMethodsPage() {
  return <ShippingEntityPage type="methods" title="طرق الشحن" />;
}

function ShippingEntityPage({ type, title }: { type: "zones" | "methods"; title: string }) {
  const queryClient = useQueryClient();
  const listPath = `/api/admin/shipping/${type}`;
  const adminPath = `/api/admin/shipping/admin/${type}`;
  const rows = useQuery({ queryKey: [listPath], queryFn: () => adminApi<AnyRecord[]>(listPath) });
  const toggle = useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) => adminApi(`${adminPath}/${id}`, { method: "PATCH", body: { isActive } }),
    onSuccess: async () => {
      toast.success("تم تحديث الشحن");
      await queryClient.invalidateQueries({ queryKey: [listPath] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر تحديث الشحن"),
  });
  const remove = useMutation({
    mutationFn: (id: string) => adminApi(`${adminPath}/${id}`, { method: "DELETE" }),
    onSuccess: async () => {
      toast.success("تم الحذف");
      await queryClient.invalidateQueries({ queryKey: [listPath] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر الحذف"),
  });
  return (
    <div className="space-y-6">
      <PageHeader title={title} description="تحديث حالة عناصر الشحن وحذف العناصر غير المستخدمة." actions={<Link href="/shipping" className="rounded-md border border-slate-200 px-3 py-2 text-sm hover:bg-slate-100">الشحن</Link>} />
      {rows.isLoading ? <LoadingState /> : rows.isError ? <ErrorState message={rows.error.message} /> : (
        <CursorDataTable
          data={rows.data ?? []}
          getRowKey={(row) => idOf(row)}
          columns={[
            { id: "name", header: "الاسم", cell: (row) => <div><div className="font-medium">{localizedText(row.name, text(row.code), "ar")}</div><div className="text-xs text-slate-500">{text(row.code ?? row.scope)}</div></div> },
            { id: "detail", header: "التفاصيل", cell: (row) => type === "zones" ? `دولة ${text(row.countryId)} / مدينة ${text(row.cityId)}` : `${text(row.etaMinDays, "0")} - ${text(row.etaMaxDays, "0")} يوم` },
            { id: "status", header: "الحالة", cell: (row) => <StatusBadge status={row.isActive === false ? "INACTIVE" : "ACTIVE"} /> },
            { id: "actions", header: "إجراء", cell: (row) => <div className="flex gap-2"><button type="button" onClick={() => toggle.mutate({ id: idOf(row), isActive: row.isActive === false })} className="rounded-md border border-slate-200 px-2 py-1 text-xs">{row.isActive === false ? "تفعيل" : "تعطيل"}</button><button type="button" onClick={() => { if (window.confirm("حذف العنصر؟")) remove.mutate(idOf(row)); }} className="rounded-md border border-red-200 px-2 py-1 text-xs text-red-700">حذف</button></div> },
          ]}
        />
      )}
    </div>
  );
}

export function ShippingVendorRatesPage() {
  const [vendorId, setVendorId] = useState("");
  const [zoneId, setZoneId] = useState("");
  const [methodId, setMethodId] = useState("");
  const [baseCents, setBaseCents] = useState("0");
  const queryClient = useQueryClient();
  const rates = useQuery({
    queryKey: ["/api/admin/vendors", vendorId, "shipping-rates"],
    queryFn: () => adminApi<AnyRecord[]>(`/api/admin/vendors/${vendorId}/shipping-rates`),
    enabled: Boolean(vendorId),
  });
  const upsert = useMutation({
    mutationFn: () => adminApi(`/api/admin/vendors/${vendorId}/shipping-rates`, { method: "POST", body: { zoneId, methodId, rateType: "FLAT", baseCents: Number(baseCents), isActive: true } }),
    onSuccess: async () => {
      toast.success("تم حفظ سعر الشحن");
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/vendors", vendorId, "shipping-rates"] });
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر حفظ سعر الشحن"),
  });
  return (
    <div className="space-y-6">
      <PageHeader title="أسعار شحن البائعين" description="عرض وإضافة أسعار الشحن للبائع عند توفر صلاحية الإدارة/البائع." />
      <PageCard>
        <form onSubmit={(event) => { event.preventDefault(); upsert.mutate(); }} className="grid gap-3 md:grid-cols-5 md:items-end">
          <TextInput label="معرف البائع" value={vendorId} onChange={setVendorId} required />
          <TextInput label="معرف المنطقة" value={zoneId} onChange={setZoneId} required />
          <TextInput label="معرف الطريقة" value={methodId} onChange={setMethodId} required />
          <TextInput label="السعر بالقروش" value={baseCents} onChange={setBaseCents} required />
          <button disabled={!vendorId || upsert.isPending} className="h-10 rounded-md bg-teal-700 px-4 text-sm font-semibold text-white disabled:opacity-50">حفظ</button>
        </form>
      </PageCard>
      {!vendorId ? <EmptyState title="أدخل معرف بائع" description="بعد إدخال معرف البائع ستظهر أسعار الشحن الخاصة به." /> : rates.isLoading ? <LoadingState /> : rates.isError ? <ErrorState message={rates.error.message} /> : (
        <CursorDataTable
          data={rates.data ?? []}
          getRowKey={(rate) => idOf(rate)}
          columns={[
            { id: "zone", header: "المنطقة", cell: (rate) => text((rate.zone as AnyRecord | undefined)?.publicId ?? rate.zoneId) },
            { id: "method", header: "الطريقة", cell: (rate) => text((rate.method as AnyRecord | undefined)?.code ?? rate.methodId) },
            { id: "amount", header: "السعر", cell: (rate) => formatMoney(rate.baseCents, "EGP") },
            { id: "status", header: "الحالة", cell: (rate) => <StatusBadge status={rate.isActive === false ? "INACTIVE" : "ACTIVE"} /> },
          ]}
        />
      )}
    </div>
  );
}

export function ShippingQuoteTesterPage() {
  const [addressId, setAddressId] = useState("");
  const quote = useMutation({
    mutationFn: () => adminApi<unknown>("/api/admin/shipping/quote", { method: "POST", body: { addressId } }),
    onError: (error) => toast.error(error instanceof Error ? error.message : "تعذر حساب الشحن"),
  });
  return (
    <div className="space-y-6">
      <PageHeader title="اختبار تسعير الشحن" description="اختبار endpoint /v1/shipping/quote بعنوان موجود." />
      <PageCard>
        <form onSubmit={(event) => { event.preventDefault(); quote.mutate(); }} className="flex gap-3">
          <div className="flex-1"><TextInput label="معرف العنوان" value={addressId} onChange={setAddressId} required /></div>
          <button disabled={quote.isPending} className="mt-6 h-10 rounded-md bg-teal-700 px-4 text-sm font-semibold text-white disabled:opacity-50">احسب</button>
        </form>
      </PageCard>
      {quote.data ? <JsonBlock value={quote.data} /> : null}
    </div>
  );
}

export function BillingGapPage({ title }: { title: string }) {
  return (
    <div className="space-y-4">
      <PageHeader title={title} description="وحدة مالية جاهزة للتوصيل عند اكتمال endpoints الفوترة الإدارية العامة." />
      <GapCard
        title="تحتاج endpoint إداري عام"
        description="الخلفية الحالية توفر بيانات الفوترة بنطاق البائع فقط، وتوفر للإدارة مراجعة دفعة وتشغيل مهمة الفوترة. هذه الصفحة تحتاج GET /v1/admin/vendor-billing/accounts أو invoices أو payments أو ledger حسب النوع."
      />
      <Link href="/billing" className="inline-flex rounded-md bg-teal-700 px-4 py-2 text-sm font-semibold text-white">فتح إجراءات الفوترة المتاحة</Link>
    </div>
  );
}

export function OpsHealthPage() {
  const health = useQuery({ queryKey: ["/api/system/health"], queryFn: () => adminApi<unknown>("/api/system/health") });
  const ready = useQuery({ queryKey: ["/api/system/health/ready"], queryFn: () => adminApi<unknown>("/api/system/health/ready") });
  const metrics = useQuery({ queryKey: ["/api/system/metrics"], queryFn: () => adminApi<unknown>("/api/system/metrics") });
  return (
    <div className="space-y-6">
      <PageHeader title="صحة النظام" description="فحوصات الصحة والمقاييس من endpoints خارج /v1 عبر proxy محمي." />
      <section className="grid gap-4 xl:grid-cols-3">
        <PageCard><div className="mb-2 text-sm font-semibold">الصحة</div>{health.isLoading ? <LoadingState /> : health.isError ? <ErrorState message={health.error.message} /> : <JsonBlock value={health.data} />}</PageCard>
        <PageCard><div className="mb-2 text-sm font-semibold">الجاهزية</div>{ready.isLoading ? <LoadingState /> : ready.isError ? <ErrorState message={ready.error.message} /> : <JsonBlock value={ready.data} />}</PageCard>
        <PageCard><div className="mb-2 text-sm font-semibold">المقاييس</div>{metrics.isLoading ? <LoadingState /> : metrics.isError ? <ErrorState message={metrics.error.message} /> : <pre className="max-h-96 overflow-auto whitespace-pre-wrap text-xs">{String(metrics.data ?? "")}</pre>}</PageCard>
      </section>
    </div>
  );
}

export function OpsQueuesPage() {
  const queues = useQuery({ queryKey: ["/api/admin/admin/ops/queues"], queryFn: () => adminApi<AnyRecord>("/api/admin/admin/ops/queues") });
  const rows = queues.data ? Object.entries(queues.data).map(([name, value]) => ({ name, value })) : [];
  return (
    <div className="space-y-6">
      <PageHeader title="طوابير النظام" description="متابعة حالة طوابير BullMQ." />
      {queues.isLoading ? <LoadingState /> : queues.isError ? <ErrorState message={queues.error.message} /> : (
        <CursorDataTable
          data={rows}
          getRowKey={(row) => row.name}
          columns={[
            { id: "name", header: "الطابور", cell: (row) => row.name },
            { id: "value", header: "الحالة", cell: (row) => <pre className="max-w-xl overflow-auto text-xs">{JSON.stringify(row.value, null, 2)}</pre> },
          ]}
        />
      )}
    </div>
  );
}

export function OpsGapPage({ title, description }: { title: string; description: string }) {
  return (
    <div className="space-y-4">
      <PageHeader title={title} description={description} />
      <GapCard title="Endpoint غير متاح بعد" description="هذه الصفحة جاهزة في لوحة الإدارة، لكنها تحتاج endpoint backend لإرجاع البيانات أو تشغيل الإجراء المطلوب." />
    </div>
  );
}

export function AuditLogDetailPage({ auditLogId }: { auditLogId: string }) {
  return (
    <div className="space-y-4">
      <PageHeader title={`تفاصيل سجل التدقيق ${auditLogId}`} description="تفاصيل سجل التدقيق ستظهر هنا عند توفر endpoint مستقل." />
      <GapCard title="لا يوجد endpoint تفاصيل" description="القائمة تعمل عبر /v1/admin/audit-logs. تحتاج التفاصيل إلى GET /v1/admin/audit-logs/:auditLogId." />
    </div>
  );
}

export function AuditExportPage() {
  return (
    <div className="space-y-4">
      <PageHeader title="تصدير سجل التدقيق" description="تصدير السجلات الحساسة يحتاج endpoint تصدير محمي." />
      <GapCard title="التصدير غير متاح بعد" description="أضف GET /v1/admin/audit-logs/export في الخلفية لتفعيل تنزيل CSV/JSON من هذه الصفحة." />
    </div>
  );
}
