"use client";

import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { useSearchParams } from "next/navigation";

import { CursorDataTable } from "@/components/data-table/cursor-data-table";
import { CursorPager } from "@/components/data-table/cursor-pager";
import { TableToolbar } from "@/components/data-table/table-toolbar";
import { PageHeader } from "@/components/layout/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/state/async-states";
import { StatusBadge } from "@/components/status/status-badge";
import { adminApi } from "@/lib/api/admin-client";
import { withQuery } from "@/lib/api/paths";
import { queryKeys } from "@/lib/api/query-keys";
import type { VendorPage } from "@/lib/api/types";
import { formatDate, localizedText } from "@/lib/formatters";

const vendorStatuses = [
  { label: "بائعون قيد المراجعة", value: "PENDING" },
  { label: "بائعون معتمدون", value: "APPROVED" },
  { label: "بائعون موقوفون", value: "SUSPENDED" },
  { label: "بائعون مرفوضون", value: "REJECTED" },
];

export default function VerificationsPage() {
  const searchParams = useSearchParams();
  const queryParams = {
    q: searchParams.get("q") ?? undefined,
    status: searchParams.get("status") ?? "PENDING",
    cursor: searchParams.get("cursor") ?? undefined,
    limit: "20",
  };

  const vendors = useQuery({
    queryKey: queryKeys.vendors({ ...queryParams, scope: "kyc" }),
    queryFn: () =>
      adminApi<VendorPage>(withQuery("/api/admin/admin/vendors", queryParams)),
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="التحقق والوثائق"
        description="endpoints قائمة التحقق العامة ما زالت فجوة backend، لذلك تبدأ هذه القائمة من حالة البائع وتوجه المراجعين إلى وثائق كل بائع."
      />

      <div className="rounded-md border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-900">
        endpoints المطلوبة لقائمة تحقق عامة حقيقية:{" "}
        <code>GET /v1/admin/verifications</code>,{" "}
        <code>GET /v1/admin/verifications/:verificationId</code>, and{" "}
        <code>PATCH /v1/admin/verifications/:verificationId/review</code>.
      </div>

      <TableToolbar
        searchPlaceholder="ابحث باسم البائع أو البريد أو slug"
        statusOptions={vendorStatuses}
      />

      {vendors.isLoading ? (
        <LoadingState label="جار تحميل قائمة التحقق" />
      ) : vendors.isError ? (
        <ErrorState message={vendors.error.message} />
      ) : (vendors.data?.data ?? []).length === 0 ? (
        <EmptyState
          title="لا يوجد بائعون في هذه القائمة"
          description="جرّب حالة أو بحثا آخر. الوثائق المرسلة تظهر من صفحة تفاصيل كل بائع."
        />
      ) : (
        <>
          <CursorDataTable
            data={vendors.data?.data ?? []}
            getRowKey={(vendor) => vendor.publicId}
            columns={[
              {
                id: "vendor",
                header: "البائع",
                cell: (vendor) => (
                  <div>
                    <Link
                      href={`/vendors/${vendor.publicId}`}
                      className="font-medium text-teal-800 hover:underline"
                    >
                      {localizedText(vendor.displayName, vendor.legalName, "ar")}
                    </Link>
                    <div className="text-xs text-slate-500">
                      {vendor.email ?? vendor.slug}
                    </div>
                  </div>
                ),
              },
              {
                id: "status",
                header: "حالة البائع",
                cell: (vendor) => <StatusBadge status={vendor.status} />,
              },
              {
                id: "counts",
                header: "مؤشرات المراجعة",
                cell: (vendor) => (
                  <div className="text-sm text-slate-600">
                    <div>{vendor._count?.members ?? 0} أعضاء</div>
                    <div>{vendor._count?.products ?? 0} منتجات</div>
                  </div>
                ),
              },
              {
                id: "created",
                header: "تاريخ الإنشاء",
                cell: (vendor) => formatDate(vendor.createdAt),
              },
              {
                id: "action",
                header: "إجراء",
                cell: (vendor) => (
                  <Link
                    href={`/vendors/${vendor.publicId}`}
                    className="rounded-md border border-slate-200 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100"
                  >
                    فتح الوثائق
                  </Link>
                ),
              },
            ]}
          />
          <CursorPager
            nextCursor={vendors.data?.nextCursor}
            hasMore={vendors.data?.hasMore}
          />
        </>
      )}
    </div>
  );
}
