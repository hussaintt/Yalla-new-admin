"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { toast } from "sonner";

import { CursorDataTable } from "@/components/data-table/cursor-data-table";
import { CursorPager } from "@/components/data-table/cursor-pager";
import { TableToolbar } from "@/components/data-table/table-toolbar";
import { PageHeader } from "@/components/layout/page-header";
import { ErrorState, LoadingState } from "@/components/state/async-states";
import { StatusBadge } from "@/components/status/status-badge";
import { adminApi } from "@/lib/api/admin-client";
import { withQuery } from "@/lib/api/paths";
import { queryKeys } from "@/lib/api/query-keys";
import type { ReviewPage } from "@/lib/api/types";
import { formatDate, formatName, localizedText } from "@/lib/formatters";

const reviewStatuses = [
  { label: "قيد المراجعة", value: "PENDING" },
  { label: "معتمد", value: "APPROVED" },
  { label: "مرفوض", value: "REJECTED" },
];

export default function ReviewsPage() {
  const searchParams = useSearchParams();
  const queryParams = {
    status: searchParams.get("status") ?? "PENDING",
    cursor: searchParams.get("cursor") ?? undefined,
    limit: "20",
  };
  const queryClient = useQueryClient();

  const reviews = useQuery({
    queryKey: queryKeys.reviews(queryParams),
    queryFn: () =>
      adminApi<ReviewPage>(withQuery("/api/admin/admin/reviews", queryParams)),
  });

  const moderateReview = useMutation({
    mutationFn: ({
      reviewId,
      status,
      reason,
    }: {
      reviewId: string;
      status: "APPROVED" | "REJECTED";
      reason?: string;
    }) =>
      adminApi(`/api/admin/admin/reviews/${reviewId}/moderate`, {
        method: "POST",
        body: { status, reason },
      }),
    onSuccess: async () => {
      toast.success("تم تحديث حالة المراجعة");
      await queryClient.invalidateQueries({ queryKey: ["reviews"] });
      await queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.overview(30) });
    },
    onError: (error) => {
      toast.error(
        error instanceof Error ? error.message : "تعذر تحديث المراجعة",
      );
    },
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="المراجعات"
        description="مراجعة تقييمات المنتجات والبائعين قبل أن تؤثر على جودة السوق."
      />

      <TableToolbar statusOptions={reviewStatuses} showSearch={false} />

      {reviews.isLoading ? (
        <LoadingState label="جار تحميل المراجعات" />
      ) : reviews.isError ? (
        <ErrorState message={reviews.error.message} />
      ) : (
        <>
          <CursorDataTable
            data={reviews.data?.data ?? []}
            getRowKey={(review) => review.publicId}
            columns={[
              {
                id: "review",
                header: "المراجعة",
                cell: (review) => (
                  <div className="max-w-md">
                    <Link href={`/reviews/${review.publicId}`} className="font-medium text-teal-800 hover:underline">
                      {review.title ?? "مراجعة بدون عنوان"}
                    </Link>
                    <p className="mt-1 line-clamp-3 text-sm leading-6 text-slate-600">
                      {review.body ?? "-"}
                    </p>
                    <div className="mt-1 text-xs text-slate-500">
                      {review.rating}/5 نجوم · مفيدة {review.helpfulCount ?? 0}
                    </div>
                  </div>
                ),
              },
              {
                id: "status",
                header: "الحالة",
                cell: (review) => <StatusBadge status={review.status} />,
              },
              {
                id: "context",
                header: "السياق",
                cell: (review) => (
                  <div className="text-sm text-slate-600">
                    <div>
                      المشتري:{" "}
                      {review.user
                        ? formatName({
                            firstName: review.user.firstName,
                            lastName: review.user.lastName,
                          })
                        : "-"}
                    </div>
                    <div>
                      المنتج:{" "}
                      {review.product?.publicId ? (
                        <Link
                          href={`/products/${review.product.publicId}`}
                          className="text-teal-800 hover:underline"
                        >
                          {localizedText(review.product.title, review.product.slug, "ar")}
                        </Link>
                      ) : (
                        localizedText(review.product?.title, review.product?.slug, "ar")
                      )}
                    </div>
                    <div>
                      البائع:{" "}
                      {review.vendor?.publicId ? (
                        <Link
                          href={`/vendors/${review.vendor.publicId}`}
                          className="text-teal-800 hover:underline"
                        >
                          {localizedText(review.vendor.displayName, review.vendor.publicId, "ar")}
                        </Link>
                      ) : (
                        "-"
                      )}
                    </div>
                  </div>
                ),
              },
              {
                id: "moderation",
                header: "الاعتدال",
                cell: (review) => (
                  <div className="text-sm text-slate-600">
                    <div>تم الإنشاء {formatDate(review.createdAt)}</div>
                    <div>تمت المراجعة {formatDate(review.moderatedAt)}</div>
                    {review.moderationReason ? (
                      <div className="mt-1 text-xs text-red-700">
                        {review.moderationReason}
                      </div>
                    ) : null}
                  </div>
                ),
              },
              {
                id: "actions",
                header: "إجراءات",
                cell: (review) => (
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      disabled={moderateReview.isPending || review.status === "APPROVED"}
                      onClick={() =>
                        moderateReview.mutate({
                          reviewId: review.publicId,
                          status: "APPROVED",
                        })
                      }
                      className="rounded-md border border-emerald-200 px-2 py-1 text-xs font-medium text-emerald-700 hover:bg-emerald-50 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      اعتماد
                    </button>
                    <button
                      type="button"
                      disabled={moderateReview.isPending || review.status === "REJECTED"}
                      onClick={() => {
                        const reason = window.prompt("سبب الرفض");
                        if (reason) {
                          moderateReview.mutate({
                            reviewId: review.publicId,
                            status: "REJECTED",
                            reason,
                          });
                        }
                      }}
                      className="rounded-md border border-red-200 px-2 py-1 text-xs font-medium text-red-700 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      رفض
                    </button>
                  </div>
                ),
              },
            ]}
          />
          <CursorPager
            nextCursor={reviews.data?.nextCursor}
            hasMore={reviews.data?.hasMore}
          />
        </>
      )}
    </div>
  );
}
